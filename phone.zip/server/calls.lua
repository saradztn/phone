-- ============================================================================
-- AURA Phone - calling system (server)
-- State machine per player:  CALLING -> RINGING(peer) -> ACTIVE -> ENDED
-- Special numbers: "911" (simulated emergency dispatch)
-- * recipient online check, busy check, timeout -> MISSED
-- * call log persisted with status + duration
-- * optional voice bridge hook (config.voice)
-- ============================================================================
local P = PhoneConfig.database.prefix
Calls = {}  -- [player] = { number, name, peer, state, started, activeAt, timer }

local function toast(player, ok, text)
    triggerClientEvent(player, "phone:toast", player, ok and 1 or 0, text)
end

local function stateTo(player, state, number, name, duration, reason)
    if isElement(player) then
        triggerClientEvent(player, "phone:call:state", player, state, number, name, duration or 0, reason or "")
    end
end

local function logCall(callerNum, calleeNum, duration, status)
    DB.run(string.format(
        "INSERT INTO %scalls (caller_number, receiver_number, duration, status, timestamp) VALUES (%s, %s, %d, %s, %d)",
        P, DB.s(callerNum), DB.s(calleeNum), duration, DB.s(status), os.time()))
end

local function voiceStart(caller, callee)
    if not PhoneConfig.voice.enabled then return end
    if isElement(caller) then triggerClientEvent(caller, "phone:voice:start", caller, PhoneConfig.voice.channel) end
    if isElement(callee) then triggerClientEvent(callee, "phone:voice:start", callee, PhoneConfig.voice.channel) end
end

local function voiceStop(caller, callee)
    if not PhoneConfig.voice.enabled then return end
    if isElement(caller) then triggerClientEvent(caller, "phone:voice:stop", caller) end
    if isElement(callee) then triggerClientEvent(callee, "phone:voice:stop", callee) end
end

--- finish the call record for one side; reason shown to that side
local function finishSide(player, reason)
    local c = Calls[player]
    if not c then return end
    local peer = c.peer
    Calls[player] = nil
    if c.timer then cancelTimer(c.timer) end
    local dur = 0
    if c.state == "ACTIVE" and c.activeAt then dur = os.time() - c.activeAt end
    stateTo(player, "ENDED", c.number, c.name, dur, reason)
    voiceStop(player, peer)
    return dur
end

--- end the whole call for both sides (used by timeout/quit)
local function finishBoth(caller, callee, reason, logStatus)
    local ca, cb = Calls[caller], Calls[callee]
    local dur = 0
    if ca and ca.state == "ACTIVE" and ca.activeAt then dur = os.time() - ca.activeAt end
    Calls[caller], Calls[callee] = nil, nil
    if ca and ca.timer then cancelTimer(ca.timer) end
    if cb and cb.timer then cancelTimer(cb.timer) end
    stateTo(caller, "ENDED", ca and ca.number or "", ca and ca.name or "", dur, reason)
    stateTo(callee, "ENDED", cb and cb.number or "", cb and cb.name or "", dur, reason)
    voiceStop(caller, callee)
    if logStatus and ca then logCall(ca.number, cb and cb.number or "", dur, logStatus) end
end

--- called from onPlayerQuit of either side
function endCallFromPeer(player)
    local c = Calls[player]
    if not c then return end
    Calls[player] = nil
    if c.timer then cancelTimer(c.timer) end
    if c.peer and isElement(c.peer) and Calls[c.peer] then
        local p = Calls[c.peer]
        Calls[c.peer] = nil
        if p.timer then cancelTimer(p.timer) end
        stateTo(c.peer, "ENDED", p.number, p.name, 0, "Disconnected")
        voiceStop(player, c.peer)
        if c.state == "ACTIVE" then
            logCall(c.number, p.number, c.activeAt and (os.time() - c.activeAt) or 0, "ENDED")
        end
    else
        stateTo(player, "ENDED", c.number, c.name, 0, "Disconnected")
    end
end

-- ---------------------------------------------------------------------------
-- start an outgoing call
-- ---------------------------------------------------------------------------
addEvent("phone:call:start", true)
addEventHandler("phone:call:start", root, function(number)
    local player = client
    local pl = Players[player]
    if not pl then return end
    if Calls[player] then toast(player, false, "You are already on a call.") return end
    if not SEC.rate(player, "call", PhoneConfig.maxCallsPerMinute, 60) then
        toast(player, false, "Too many calls, wait a moment.")
        SEC.reject(player, "call rate limit", "call:start")
        return
    end
    number = SEC.number(number)
    if not number then toast(player, false, "Invalid number.") return end

    -- 911: simulated dispatch
    if number == "911" then
        local c = {
            number = "911", name = "Emergency", peer = nil, state = "CALLING", started = os.time(),
            timer = setTimer(function()
                if Calls[player] and Calls[player].number == "911" then
                    finishSide(player, "Connected to dispatch")
                    phoneNotify(player, "911", "A police unit has been notified of your location.", "emergency")
                    SEC.audit("EMERGENCY_CALL", player, "911 dispatch connected")
                end
            end, 4000, 1),
        }
        Calls[player] = c
        stateTo(player, "CALLING", "911", "Emergency")
        return
    end

    if number == pl.number then toast(player, false, "You cannot call yourself.") return end
    if not NUMBERS[number] then
        toast(player, false, "This number does not exist.")
        return
    end
    local tname = nameForNumber(number)
    local target = ONLINE[number]

    if not target then
        logCall(pl.number, number, 0, "MISSED")
        DB.run(string.format(
            "INSERT INTO %snotifications (owner_id, app, title, body, timestamp) VALUES (%s, 'calls', 'Missed call', 'You missed a call from %s.', %d)",
            P, DB.s(NUMBERS[number].pkey), DB.s(getPlayerName(player)), os.time()))
        stateTo(player, "ENDED", number, tname, 0, "Number not available")
        return
    end
    if target == player then toast(player, false, "You cannot call yourself.") return end
    if Calls[target] then
        logCall(pl.number, number, 0, "BUSY")
        stateTo(player, "ENDED", number, tname, 0, "User busy")
        return
    end

    local caller = { number = number, name = tname, peer = target, state = "CALLING", started = os.time() }
    local callee = { number = pl.number, name = getPlayerName(player), peer = player, state = "RINGING", started = os.time() }
    caller.timer = setTimer(function()
        local ca = Calls[player]
        if ca and ca.state == "CALLING" then
            finishBoth(player, target, "Missed call", "MISSED")
            triggerClientEvent(target, "phone:count", target, "calls", 1)
        end
    end, PhoneConfig.callTimeout * 1000, 1)

    caller.role = "caller"
    callee.role = "callee"
    Calls[player] = caller
    Calls[target] = callee
    stateTo(player, "CALLING", number, tname)
    triggerClientEvent(target, "phone:call:incoming", target, pl.number, getPlayerName(player))
    SEC.audit("CALL_START", player, "calling " .. number)
end)

-- ---------------------------------------------------------------------------
-- accept (callee)
-- ---------------------------------------------------------------------------
addEvent("phone:call:accept", true)
addEventHandler("phone:call:accept", root, function()
    local player = client
    local c = Calls[player]
    if not c or c.state ~= "RINGING" then return end
    c.state = "ACTIVE"
    c.activeAt = os.time()
    if c.timer then
        cancelTimer(c.timer)
        c.timer = nil
    end
    local peer = c.peer
    local pc = peer and Calls[peer]
    if pc then
        pc.state = "ACTIVE"
        pc.activeAt = os.time()
    end
    stateTo(player, "ACTIVE", c.number, c.name)
    stateTo(peer, "ACTIVE", pc and pc.number or "", pc and pc.name or "")
    voiceStart(peer, player)
    SEC.audit("CALL_ACCEPT", player, "call with " .. c.number)
end)

-- ---------------------------------------------------------------------------
-- decline (callee before accepting)
-- ---------------------------------------------------------------------------
addEvent("phone:call:decline", true)
addEventHandler("phone:call:decline", root, function()
    local player = client
    local c = Calls[player]
    if not c or c.state ~= "RINGING" then return end
    local peer = c.peer
    finishSide(player, "Declined")
    if peer and isElement(peer) then
        local pc = Calls[peer]
        if pc then
            finishSide(peer, "Declined")
            logCall(pc.number, c.number, 0, "REJECTED")
        end
    end
end)

-- ---------------------------------------------------------------------------
-- hang up (either side, any state)
-- ---------------------------------------------------------------------------
addEvent("phone:call:end", true)
addEventHandler("phone:call:end", root, function()
    local player = client
    local c = Calls[player]
    if not c then return end
    local peer = c.peer

    if c.state == "ACTIVE" then
        local pc = peer and Calls[peer]
        if peer and isElement(peer) and pc then
            local dur = c.activeAt and (os.time() - c.activeAt) or 0
            if c.timer then cancelTimer(c.timer) end
            if pc.timer then cancelTimer(pc.timer) end
            Calls[player], Calls[peer] = nil, nil
            stateTo(player, "ENDED", c.number, c.name, dur, "Ended")
            stateTo(peer, "ENDED", pc.number, pc.name, dur, "Ended")
            voiceStop(player, peer)
            local myNum = Players[player] and Players[player].number or c.number
            logCall(c.role == "caller" and myNum or pc.number, c.role == "caller" and pc.number or myNum, dur, "ENDED")
        else
            finishSide(player, "Ended")
        end
    elseif c.state == "RINGING" then
        -- the ringing side hangs up = decline
        local peerC = peer and Calls[peer]
        finishSide(player, "Declined")
        if peer and isElement(peer) and peerC then
            finishSide(peer, "Declined")
            local callerNum = Players[peer] and Players[peer].number or peerC.number
            local calleeNum = Players[player] and Players[player].number or c.number
            logCall(callerNum, calleeNum, 0, "REJECTED")
        end
    else
        -- caller canceled
        finishSide(player, "Canceled")
        if peer and isElement(peer) and Calls[peer] then
            finishSide(peer, "Canceled")
        end
    end
end)

-- ---------------------------------------------------------------------------
-- call log
-- ---------------------------------------------------------------------------
addEvent("phone:calllog:fetch", true)
addEventHandler("phone:calllog:fetch", root, function()
    local player = client
    local pl = Players[player]
    if not pl then return end
    DB.select(string.format(
        "SELECT caller_number, receiver_number, duration, status, timestamp FROM %scalls "
        .. "WHERE caller_number = %s OR receiver_number = %s ORDER BY timestamp DESC LIMIT 30",
        P, DB.s(pl.number), DB.s(pl.number)), function(ok, rows)
        local out = {}
        for _, r in ipairs(rows or {}) do
            local mine = r.caller_number == pl.number
            local other = mine and r.receiver_number or r.caller_number
            table.insert(out, {
                number = other,
                name = nameForNumber(other),
                mine = mine,
                status = r.status,
                duration = r.duration or 0,
                time = r.timestamp,
            })
        end
        triggerClientEvent(player, "phone:calllog:data", player, out)
    end)
end)
