-- ============================================================================
-- AURA Phone - database layer (server)
-- * connects to MySQL (any MTA db driver works through dbConnect)
-- * auto-creates the schema on start (CREATE TABLE IF NOT EXISTS)
-- * all queries go through escape helpers: strings via dbEscapeString,
--   numbers via tonumber() coercion -> SQL injection is not possible
--   (MTA's MySQL API does not expose server-side prepared statements,
--    so this strict parameter layer is the equivalent protection here)
-- * async results through dbQuery + onQueryComplete (never blocks a frame)
-- ============================================================================
DB = { conn = nil, P = PhoneConfig.database.prefix }

local P = PhoneConfig.database.prefix

DB.schema = {
    "CREATE TABLE IF NOT EXISTS " .. P .. "numbers ("
        .. "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, "
        .. "`account_id` VARCHAR(64) NOT NULL, "
        .. "`phone_number` VARCHAR(16) NOT NULL, "
        .. "`display_name` VARCHAR(32) NOT NULL DEFAULT '', "
        .. "`created_at` INT UNSIGNED NOT NULL, "
        .. "PRIMARY KEY (`id`), "
        .. "UNIQUE KEY `uniq_account` (`account_id`), "
        .. "UNIQUE KEY `uniq_number` (`phone_number`)) ENGINE=InnoDB DEFAULT CHARSET=utf8",

    "CREATE TABLE IF NOT EXISTS " .. P .. "contacts ("
        .. "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, "
        .. "`owner_id` VARCHAR(64) NOT NULL, "
        .. "`contact_number` VARCHAR(16) NOT NULL, "
        .. "`contact_name` VARCHAR(32) NOT NULL, "
        .. "`favorite` TINYINT NOT NULL DEFAULT 0, "
        .. "`created_at` INT UNSIGNED NOT NULL, "
        .. "PRIMARY KEY (`id`), "
        .. "UNIQUE KEY `uniq_owner_contact` (`owner_id`, `contact_number`), "
        .. "KEY `idx_owner` (`owner_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8",

    "CREATE TABLE IF NOT EXISTS " .. P .. "messages ("
        .. "`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, "
        .. "`sender_number` VARCHAR(16) NOT NULL, "
        .. "`receiver_number` VARCHAR(16) NOT NULL, "
        .. "`message` VARCHAR(512) NOT NULL, "
        .. "`timestamp` INT UNSIGNED NOT NULL, "
        .. "`is_read` TINYINT NOT NULL DEFAULT 0, "
        .. "`read_at` INT UNSIGNED NULL, "
        .. "PRIMARY KEY (`id`), "
        .. "KEY `idx_receiver` (`receiver_number`, `is_read`), "
        .. "KEY `idx_pair` (`sender_number`, `receiver_number`, `timestamp`)) ENGINE=InnoDB DEFAULT CHARSET=utf8",

    "CREATE TABLE IF NOT EXISTS " .. P .. "calls ("
        .. "`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, "
        .. "`caller_number` VARCHAR(16) NOT NULL, "
        .. "`receiver_number` VARCHAR(16) NOT NULL, "
        .. "`duration` INT UNSIGNED NOT NULL DEFAULT 0, "
        .. "`status` VARCHAR(12) NOT NULL DEFAULT 'ENDED', "
        .. "`timestamp` INT UNSIGNED NOT NULL, "
        .. "PRIMARY KEY (`id`), "
        .. "KEY `idx_parties` (`caller_number`, `receiver_number`)) ENGINE=InnoDB DEFAULT CHARSET=utf8",

    "CREATE TABLE IF NOT EXISTS " .. P .. "notifications ("
        .. "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, "
        .. "`owner_id` VARCHAR(64) NOT NULL, "
        .. "`app` VARCHAR(24) NOT NULL, "
        .. "`title` VARCHAR(64) NOT NULL, "
        .. "`body` VARCHAR(160) NOT NULL, "
        .. "`timestamp` INT UNSIGNED NOT NULL, "
        .. "PRIMARY KEY (`id`), "
        .. "KEY `idx_owner` (`owner_id`, `timestamp`)) ENGINE=InnoDB DEFAULT CHARSET=utf8",

    "CREATE TABLE IF NOT EXISTS " .. P .. "notes ("
        .. "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, "
        .. "`owner_id` VARCHAR(64) NOT NULL, "
        .. "`title` VARCHAR(48) NOT NULL, "
        .. "`body` VARCHAR(2048) NOT NULL, "
        .. "`created_at` INT UNSIGNED NOT NULL, "
        .. "`updated_at` INT UNSIGNED NOT NULL, "
        .. "PRIMARY KEY (`id`), "
        .. "KEY `idx_owner` (`owner_id`, `updated_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8",

    "CREATE TABLE IF NOT EXISTS " .. P .. "settings ("
        .. "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, "
        .. "`owner_id` VARCHAR(64) NOT NULL, "
        .. "`skey` VARCHAR(32) NOT NULL, "
        .. "`svalue` VARCHAR(128) NOT NULL, "
        .. "PRIMARY KEY (`id`), "
        .. "UNIQUE KEY `uniq_owner_key` (`owner_id`, `skey`)) ENGINE=InnoDB DEFAULT CHARSET=utf8",

    "CREATE TABLE IF NOT EXISTS " .. P .. "apps ("
        .. "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, "
        .. "`owner_id` VARCHAR(64) NOT NULL, "
        .. "`app_id` VARCHAR(24) NOT NULL, "
        .. "`installed` TINYINT NOT NULL DEFAULT 1, "
        .. "PRIMARY KEY (`id`), "
        .. "UNIQUE KEY `uniq_owner_app` (`owner_id`, `app_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8",

    "CREATE TABLE IF NOT EXISTS " .. P .. "bank_tx ("
        .. "`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, "
        .. "`from_number` VARCHAR(16) NOT NULL, "
        .. "`to_number` VARCHAR(16) NOT NULL, "
        .. "`amount` INT UNSIGNED NOT NULL, "
        .. "`timestamp` INT UNSIGNED NOT NULL, "
        .. "PRIMARY KEY (`id`), "
        .. "KEY `idx_pair` (`from_number`, `to_number`, `timestamp`)) ENGINE=InnoDB DEFAULT CHARSET=utf8",

    "CREATE TABLE IF NOT EXISTS " .. P .. "bank_pending ("
        .. "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, "
        .. "`to_number` VARCHAR(16) NOT NULL, "
        .. "`amount` INT UNSIGNED NOT NULL, "
        .. "`timestamp` INT UNSIGNED NOT NULL, "
        .. "PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8",

    "CREATE TABLE IF NOT EXISTS " .. P .. "vehicles ("
        .. "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, "
        .. "`owner_id` VARCHAR(64) NOT NULL, "
        .. "`name` VARCHAR(64) NOT NULL, "
        .. "`model` VARCHAR(64) NOT NULL DEFAULT '', "
        .. "`vehicle` INT UNSIGNED NOT NULL DEFAULT 0, "
        .. "`last_x` FLOAT NOT NULL DEFAULT 0, "
        .. "`last_y` FLOAT NOT NULL DEFAULT 0, "
        .. "`last_z` FLOAT NOT NULL DEFAULT 0, "
        .. "`locked` TINYINT NOT NULL DEFAULT 0, "
        .. "`engine` TINYINT NOT NULL DEFAULT 0, "
        .. "`updated_at` INT UNSIGNED NOT NULL, "
        .. "PRIMARY KEY (`id`), "
        .. "KEY `idx_owner` (`owner_id`), "
        .. "KEY `idx_vehicle` (`vehicle`)) ENGINE=InnoDB DEFAULT CHARSET=utf8",

    "CREATE TABLE IF NOT EXISTS " .. P .. "properties ("
        .. "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, "
        .. "`owner_id` VARCHAR(64) NOT NULL, "
        .. "`name` VARCHAR(64) NOT NULL, "
        .. "`ptype` VARCHAR(32) NOT NULL DEFAULT 'House', "
        .. "`x` FLOAT NOT NULL DEFAULT 0, "
        .. "`y` FLOAT NOT NULL DEFAULT 0, "
        .. "`z` FLOAT NOT NULL DEFAULT 0, "
        .. "PRIMARY KEY (`id`), "
        .. "KEY `idx_owner` (`owner_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8",
}

function DB.init()
    local c = PhoneConfig.database
    DB.conn = dbConnect(c.type, c.name, c.host, c.user, c.pass, c.port)
    if not DB.conn then
        outputConsole("[phone] ERROR: cannot connect to database " .. c.type .. "://" .. c.host .. ":" .. tostring(c.port) .. "/" .. c.name)
        outputConsole("[phone]   1) Is MySQL/MariaDB running on this machine?  2) Does the database exist?  3) Check the 'database' block in shared/config.lua")
        outputConsole("[phone] The resource keeps loading but nothing will be stored until the database is available. Restart it afterwards (stop/start phone).")
        return false
    end
    for _, q in ipairs(DB.schema) do
        dbExec(DB.conn, q)
    end
    outputConsole("[phone] Database connected (" .. c.name .. "), schema ready.")
    return true
end

--- escape a string for use inside a query
function DB.s(v)
    local v = tostring(v == nil and "" or v)
    if not DB.conn then return "'" .. v:gsub("'", "") .. "'" end
    return dbEscapeString(DB.conn, v)
end

--- coerce to an integer string (safe) or nil
function DB.i(v)
    v = tonumber(v)
    if v and v == math.floor(v) then return tostring(v) end
    return nil
end

local function collectResult(result, cb)
    addEventHandler("onQueryComplete", result, function(_, res)
        if res then
            local rows = {}
            while true do
                local row = dbFetch(res)
                if not row then break end
                table.insert(rows, row)
            end
            local affected = dbNumRows(res) or 0
            dbFree(res)
            cb(true, rows, affected)
        else
            cb(false, nil, 0)
        end
    end)
end

--- async SELECT. cb(ok, rows)
function DB.select(q, cb)
    if not DB.conn then
        if cb then cb(false, nil, 0) end
        return
    end
    local res = dbQuery(DB.conn, q)
    if res then collectResult(res, cb) else cb(false, nil, 0) end
end

--- async INSERT/UPDATE/DELETE. cb(ok, rows, affected)
function DB.run(q, cb)
    DB.select(q, cb)
end
