-- ============================================================================
-- AURA Phone - server core
-- * player identity (account guid or name based pkey)
-- * unique phone number assignment on join
-- * number registry cache for name resolution / online lookup
-- * init handshake, cleanup, exports for other resources
-- ============================================================================
Players = {}   -- [player] = { number, pkey }
NUMBERS = {}   -- [number]  = { pkey, name }
ONLINE = {}    -- [number]  = player element

local P = PhoneConfig.database.prefix

function pkeyOf(player)
    local acc = getAccountName(player)
    if acc and acc ~= "" then return acc end
    return "name:" .. getPlayerName(player)
end

local function genNumber()
    local s = PhoneConfig.numberPrefix
    for _ = 1, PhoneConfig.numberLength - #PhoneConfig.numberPrefix do
        s = s .. math.random(0, 9)
    end
    return s
end

local function registerOnline(player)
    local pl = Players[player]
    if not pl then return end
    ONLINE[pl.number] = player
    NUMBERS[pl.number] = { pkey = pl.pkey, name = getPlayerName(player) }
end

local function unregisterOnline(player)
    local pl = Players[player]
    if not pl then return end
    if ONLINE[pl.number] == player then ONLINE[pl.number] = nil end
    -- keep NUMBERS entry (offline names still resolvable)
end

local function countUnread(player, pl)
    DB.select("SELECT COUNT(*) AS c FROM " .. P .. "messages WHERE receiver_number = " .. DB.s(pl.number) .. " AND is_read = 0",
        function(ok, rows)
            local n = ok and rows and tonumber(rows[1].c) or 0
            triggerClientEvent(player, "phone:count", player, "msgs", n)
        end)
end

-- ---------------------------------------------------------------------------
-- init handshake: settings + installed apps + counts -> client
-- ---------------------------------------------------------------------------
local function finalizeInit(player)
    local pl = Players[player]
    if not pl then return end
    registerOnline(player)

    DB.select("SELECT skey, svalue FROM " .. P .. "settings WHERE owner_id = " .. DB.s(pl.pkey), function(ok, rows)
        local settings = {}
        for _, r in ipairs(rows or {}) do settings[r.skey] = r.svalue end
        triggerClientEvent(player, "phone:settings:load", player, settings)
    end)

    DB.select("SELECT app_id FROM " .. P .. "apps WHERE owner_id = " .. DB.s(pl.pkey) .. " AND installed = 1", function(ok, rows)
        local installed = {}
        for _, r in ipairs(rows or {}) do installed[r.app_id] = true end
        triggerClientEvent(player, "phone:apps:load", player, installed)
    end)

    countUnread(player, pl)
    applyPendingCredits(player)
end

-- ---------------------------------------------------------------------------
-- join / quit
-- ---------------------------------------------------------------------------
addEventHandler("onPlayerJoin", root, function(player)
    local pkey = pkeyOf(player)
    DB.select("SELECT phone_number, display_name FROM " .. P .. "numbers WHERE account_id = " .. DB.s(pkey), function(ok, rows)
        local row = ok and rows and rows[1]
        if row and row.phone_number then
            Players[player] = { number = row.phone_number, pkey = pkey }
            -- keep display name fresh (used for name resolution)
            DB.run("UPDATE " .. P .. "numbers SET display_name = " .. DB.s(getPlayerName(player)) .. " WHERE phone_number = " .. DB.s(row.phone_number))
            finalizeInit(player)
        else
            -- assign a fresh unique number (retry on the rare unique collision)
            local attempts = 0
            local function tryInsert()
                attempts = attempts + 1
                local num = genNumber()
                DB.run(string.format(
                    "INSERT IGNORE INTO %snumbers (account_id, phone_number, display_name, created_at) VALUES (%s, %s, %s, %d)",
                    P, DB.s(pkey), DB.s(num), DB.s(getPlayerName(player)), os.time()),
                    function(ok2, _rows2, affected)
                        if ok2 and affected > 0 then
                            Players[player] = { number = num, pkey = pkey }
                            finalizeInit(player)
                        elseif attempts >= 6 then
                            -- extremely unlucky; keep going with the number anyway
                            Players[player] = { number = num, pkey = pkey }
                            finalizeInit(player)
                        else
                            tryInsert()
                        end
                    end)
            end
            tryInsert()
        end
    end)
end)

addEventHandler("onPlayerQuit", root, function(player)
    -- end any active call cleanly (calls.lua provides endCallFromPeer)
    if endCallFromPeer then endCallFromPeer(player) end
    unregisterOnline(player)
    Players[player] = nil
    SEC.rl[player] = nil
end)

-- ---------------------------------------------------------------------------
-- resource start: db + number registry
-- ---------------------------------------------------------------------------
addEventHandler("onResourceStart", resourceRoot, function()
    if not DB.init() then return end
    DB.select("SELECT phone_number, account_id, display_name FROM " .. P .. "numbers", function(ok, rows)
        for _, r in ipairs(rows or {}) do
            NUMBERS[r.phone_number] = { pkey = r.account_id, name = r.display_name or "Unknown" }
        end
    end)
end)

addEventHandler("onResourceStop", resourceRoot, function()
    for _, player in pairs(getElementsByType("player")) do
        if endCallFromPeer then endCallFromPeer(player) end
    end
end)

-- ---------------------------------------------------------------------------
-- helper used by other server code
-- ---------------------------------------------------------------------------
function nameForNumber(number)
    local n = NUMBERS[number]
    return n and (n.name ~= "" and n.name or "Unknown") or "Unknown"
end

function playerForNumber(number)
    return ONLINE[number]
end

-- ---------------------------------------------------------------------------
-- exports for other resources
-- ---------------------------------------------------------------------------
function phoneNotify(player, title, msg, icon)
    if not isElement(player) then return false end
    triggerClientEvent(player, "phone:notify", player, icon or "notifications", SEC.s(title, 64) or "Notification", SEC.s(msg, 160) or "")
    local pl = Players[player]
    if pl then
        DB.run(string.format(
            "INSERT INTO %snotifications (owner_id, app, title, body, timestamp) VALUES (%s, %s, %s, %s, %d)",
            P, DB.s(pl.pkey), DB.s(icon or "notifications"), DB.s(SEC.s(title, 64) or "Notification"), DB.s(SEC.s(msg, 160) or ""), os.time()))
    end
    return true
end
SEC.export("phoneNotify", phoneNotify)

function phoneGetNumber(player)
    local pl = Players[player]
    return pl and pl.number or nil
end
SEC.export("phoneGetNumber", phoneGetNumber)
