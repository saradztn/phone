-- ============================================================================
-- AURA Phone - messaging (server)
-- * send / receive / read receipts / delete / conversation list
-- * recipient must exist; rate limited; unread count cache per player
-- * everything validated + escaped here (never trust the client)
-- ============================================================================
local P = PhoneConfig.database.prefix
UNREAD = {}  -- [player] = number of unread messages (server cache)

local function toast(player, ok, text)
    triggerClientEvent(player, "phone:toast", player, ok and 1 or 0, text)
end

local function unreadPush(player)
    triggerClientEvent(player, "phone:count", player, "msgs", UNREAD[player] or 0)
end

-- ---------------------------------------------------------------------------
-- conversation list (last message + unread per contact, sorted by recency)
-- ---------------------------------------------------------------------------
addEvent("phone:chats:fetch", true)
addEventHandler("phone:chats:fetch", root, function()
    local player = client
    local pl = Players[player]
    if not pl then return end
    DB.select(string.format(
        "SELECT sender_number, receiver_number, message, timestamp FROM %smessages "
        .. "WHERE sender_number = %s OR receiver_number = %s ORDER BY timestamp DESC LIMIT 300",
        P, DB.s(pl.number), DB.s(pl.number)), function(ok, rows)
        local groups = {}
        for _, r in ipairs(rows or {}) do
            local other = r.sender_number == pl.number and r.receiver_number or r.sender_number
            local g = groups[other]
            if not g then
                g = { number = other, name = nameForNumber(other), last = "", time = 0, unread = 0 }
                groups[other] = g
            end
            if g.last == "" then g.last = r.message end
            if not g.time or g.time < (r.timestamp or 0) then g.time = r.timestamp end
        end
        local list = {}
        for _, g in pairs(groups) do table.insert(list, g) end
        table.sort(list, function(a, b) return a.time > b.time end)
        triggerClientEvent(player, "phone:chats:list", player, list)
    end)
end)

-- ---------------------------------------------------------------------------
-- thread (100 most recent, ascending) + mark received messages as read
-- ---------------------------------------------------------------------------
addEvent("phone:thread:fetch", true)
addEventHandler("phone:thread:fetch", root, function(number)
    local player = client
    local pl = Players[player]
    number = SEC.number(number)
    if not pl or not number then return end
    if number == pl.number then return end
    local eMine, eOther = DB.s(pl.number), DB.s(number)
    DB.select(string.format(
        "SELECT sender_number, message, timestamp, read_at FROM %smessages "
        .. "WHERE (sender_number = %s AND receiver_number = %s) OR (sender_number = %s AND receiver_number = %s) "
        .. "ORDER BY timestamp DESC LIMIT 100",
        P, eMine, eOther, eOther, eMine), function(ok, rows)
        local out = {}
        for _, r in ipairs(rows or {}) do
            table.insert(out, {
                mine = r.sender_number == pl.number,
                text = r.message,
                time = r.timestamp,
                read = r.read_at or 0,
            })
        end
        local asc = {}
        for i = #out, 1, -1 do table.insert(asc, out[i]) end
        triggerClientEvent(player, "phone:thread:data", player, number, asc)
    end)
    -- mark read (after selecting, so the snapshot is stable)
    DB.run(string.format(
        "UPDATE %smessages SET is_read = 1, read_at = %d WHERE receiver_number = %s AND sender_number = %s AND is_read = 0",
        P, os.time(), eMine, eOther), function()
        UNREAD[player] = 0
        unreadPush(player)
    end)
end)

-- ---------------------------------------------------------------------------
-- send
-- ---------------------------------------------------------------------------
addEvent("phone:msg:send", true)
addEventHandler("phone:msg:send", root, function(number, text)
    local player = client
    local pl = Players[player]
    if not pl then return end
    number = SEC.number(number)
    text = SEC.s(text, PhoneConfig.maxMessageLength)
    if not number then toast(player, false, "Invalid phone number.") return end
    if not text then toast(player, false, "Message is empty or too long.") return end
    if number == pl.number then toast(player, false, "You cannot message yourself.") return end
    if not NUMBERS[number] then
        toast(player, false, "This number does not exist.")
        SEC.reject(player, "message to unknown number " .. number, "msg:send")
        return
    end
    if not SEC.rate(player, "msg", PhoneConfig.maxMessagesPerMinute, 60) then
        toast(player, false, "You are typing too fast.")
        SEC.reject(player, "message rate limit", "msg:send")
        return
    end
    local t = os.time()
    DB.run(string.format(
        "INSERT INTO %smessages (sender_number, receiver_number, message, timestamp, is_read, read_at) VALUES (%s, %s, %s, %d, 0, NULL)",
        P, DB.s(pl.number), DB.s(number), DB.s(text), t), function(ok)
        if not ok then toast(player, false, "Failed to send message.") return end
        triggerClientEvent(player, "phone:msg:echo", player, number, text, t)
        local target = ONLINE[number]
        if target and target ~= player then
            triggerClientEvent(target, "phone:msg:new", target, pl.number, getPlayerName(player), text, t)
            UNREAD[target] = (UNREAD[target] or 0) + 1
            unreadPush(target)
        end
    end)
end)

-- ---------------------------------------------------------------------------
-- delete a whole conversation (both directions)
-- ---------------------------------------------------------------------------
addEvent("phone:msg:del", true)
addEventHandler("phone:msg:del", root, function(number)
    local player = client
    local pl = Players[player]
    number = SEC.number(number)
    if not pl or not number then return end
    DB.run(string.format(
        "DELETE FROM %smessages WHERE (sender_number = %s AND receiver_number = %s) OR (sender_number = %s AND receiver_number = %s)",
        P, DB.s(pl.number), DB.s(number), DB.s(number), DB.s(pl.number)), function(ok)
        toast(player, ok and true or false, ok and "Conversation deleted" or "Delete failed")
        if ok then
            local target = ONLINE[number]
            if target then
                triggerClientEvent(target, "phone:toast", target, true, "This conversation was deleted by " .. getPlayerName(player))
            end
        end
    end)
end)
