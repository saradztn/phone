-- ============================================================================
-- AURA Phone - contacts (server)
-- Per-player contact list with favorites. Stored by owner pkey + number.
-- ============================================================================
local P = PhoneConfig.database.prefix

local function toast(player, ok, text)
    triggerClientEvent(player, "phone:toast", player, ok and 1 or 0, text)
end

local function pushList(player, filter)
    local pl = Players[player]
    local q = "SELECT contact_number, contact_name, favorite FROM " .. P .. "contacts WHERE owner_id = " .. DB.s(pl.pkey)
    if filter then q = q .. " AND (contact_name LIKE " .. DB.s("%" .. filter .. "%") .. " OR contact_number LIKE " .. DB.s(filter) .. ")" end
    q = q .. " ORDER BY favorite DESC, contact_name ASC LIMIT " .. PhoneConfig.maxContacts
    DB.select(q, function(ok, rows)
        local list = {}
        for _, r in ipairs(rows or {}) do
            table.insert(list, { number = r.contact_number, name = r.contact_name, favorite = (r.favorite == 1) })
        end
        triggerClientEvent(player, "phone:contacts:list", player, list)
    end)
end

addEvent("phone:contacts:fetch", true)
addEventHandler("phone:contacts:fetch", root, function()
    local player = client
    if not Players[player] then return end
    pushList(player)
end)

addEvent("phone:contacts:search", true)
addEventHandler("phone:contacts:search", root, function(query)
    local player = client
    if not Players[player] then return end
    query = SEC.s(query, 32)
    pushList(player, (query and #query > 0) and query or nil)
end)

addEvent("phone:contacts:save", true)
addEventHandler("phone:contacts:save", root, function(number, name)
    local player = client
    local pl = Players[player]
    number = SEC.number(number)
    name = SEC.s(name, PhoneConfig.maxContactName)
    if not pl or not number or not name then
        toast(player, false, "Invalid contact data.")
        return
    end
    if number == pl.number then
        toast(player, false, "You already have your own number.")
        return
    end
    DB.select("SELECT COUNT(*) AS c FROM " .. P .. "contacts WHERE owner_id = " .. DB.s(pl.pkey), function(ok, rows)
        local count = ok and rows and tonumber(rows[1].c) or 0
        local exists
        DB.select("SELECT id FROM " .. P .. "contacts WHERE owner_id = " .. DB.s(pl.pkey) .. " AND contact_number = " .. DB.s(number), function(ok2, rows2)
            exists = ok2 and rows2 and rows2[1]
            if not exists and count >= PhoneConfig.maxContacts then
                toast(player, false, "Contact list is full.")
                return
            end
            if exists then
                DB.run("UPDATE " .. P .. "contacts SET contact_name = " .. DB.s(name) .. " WHERE id = " .. DB.i(exists.id), function()
                    toast(player, true, "Contact updated")
                    pushList(player)
                end)
            else
                DB.run(string.format(
                    "INSERT INTO %scontacts (owner_id, contact_number, contact_name, favorite, created_at) VALUES (%s, %s, %s, 0, %d)",
                    P, DB.s(pl.pkey), DB.s(number), DB.s(name), os.time()), function()
                    toast(player, true, "Contact added")
                    pushList(player)
                end)
            end
        end)
    end)
end)

addEvent("phone:contacts:delete", true)
addEventHandler("phone:contacts:delete", root, function(number)
    local player = client
    local pl = Players[player]
    number = SEC.number(number)
    if not pl or not number then return end
    DB.run("DELETE FROM " .. P .. "contacts WHERE owner_id = " .. DB.s(pl.pkey) .. " AND contact_number = " .. DB.s(number), function(ok)
        toast(player, ok and true or false, ok and "Contact deleted" or "Delete failed")
        pushList(player)
    end)
end)

addEvent("phone:contacts:fav", true)
addEventHandler("phone:contacts:fav", root, function(number, flag)
    local player = client
    local pl = Players[player]
    number = SEC.number(number)
    if not pl or not number then return end
    DB.run("UPDATE " .. P .. "contacts SET favorite = " .. (flag and 1 or 0) .. " WHERE owner_id = " .. DB.s(pl.pkey) .. " AND contact_number = " .. DB.s(number))
    pushList(player)
end)
