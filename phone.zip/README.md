# AURA Phone — نظام هاتف ذكي متكامل لـ MTA:SA

نظام هاتف داخلي (In-Game Smartphone) احترافي لسيرفرات Roleplay، مبنى بالكامل بـ Lua
لواجهة DX (سريعة وخفيفة) مع خادم MySQL لحفظ البيانات.

**الافتتاح:** زر `F8` افتراضياً (قابل للتعديل من `shared/config.lua`).

---

## 1) المميزات

| المجال | التفاصيل |
|---|---|
| الهاتف | فتح/إغلاق بأنيميشن سلس، شاشة قفل، ساعة/تاريخ حقيقيان، بطارية، إشارة حسب الـ Ping، Dynamic Island، وضع داكن/فاتح، تغيير الخلفية، تغيير حجم الواجهة |
| المكالمات | KEYPAD، سجل المكالمات، حالات (Calling/Ringing/Active/Missed/Declined/Busy/Ended)، رنين، تحديد المدة، مكالمة 911 وهمية، سجل دائم |
| الرسائل | محادثات بين اللاعبين، قراءة/علامات ✓، غير مقروء، بحث، حذف محادثة، منع إرسال لأرقام غير موجودة، Rate Limit |
| جهات الاتصال | إضافة/تعديل/حذف/بحث/مفضلة، محفوظة لكل لاعب |
| البنك | رصيد، تحويل (مُتحقق منه 100% من السيرفر)، سجل العمليات، ترصيد للاعبين أوفلاين، منع التحويل لنفسك |
| الخرائط | POIs مع المسافة الحية، تحديد/إزالة Waypoint (Blip) |
| الكاميرا | لقطات شاشة حقيقية (screenShotToFile) + ألبوم صور |
| المركبات | تسجيل السيارة الحالية، قفل/فتح، تشغيل/إيقاف المحرك، GPS — كل الإجراءات من السيرفر مع التحقق من الملكية |
| العقارات | قائمة ممتلكات + GPS (يُربط مع Resource البيوت عبر export) |
| الوظائف | وظيفتك الحالية + عروض الوظائف + GPS |
| الطوارئ | 911 + استدعاء شرطة/مستشفى |
| المتجر | تثبيت/إزالة التطبيقات (حفظ لكل لاعب) + تطبيقات قادمة |
| الإشعارات | Toasts متحركة + Notification Center |
| الأمان | كل البيانات تُتحقق في السيرفر، Escape لكل القيم، Rate Limits، سجل تدقيق (Audit Log) |
| الأداء | Render فقط عند فتح الهاتف، Caching، Lazy Loading، قوائم Virtualized |

---

## 2) هيكل المشروع وشرح كل ملف

```
phone/
├── meta.xml                  وصف الـ Resource + ترتيب التحميل + الملفات والأصوات
│
├── shared/
│   ├── config.lua            كل الإعدادات: المفتاح، الحدود، الأصوات، POIs، الوظائف، قاعدة البيانات، Theme defaults
│   ├── utils.lua             أدوات مشتركة: تنسيق المال/المدة/الوقت، initials، hash
│   └── apps.lua              كتالوج التطبيقات (id/name/icon/order/desc) — المصدر الوحيد للحقيقة
│
├── server/
│   ├── database.lua          اتصال MySQL، إنشاء الجداول تلقائياً، طبقة استعلامات آمنة (escape + type coercion)، نتائج async
│   ├── security.lua          المحاكد (validators) + Rate Limit + سجل التدقيق
│   ├── main.lua              هوية اللاعب (pkey)، توزيع أرقام فريدة، handshake مع الكلاينت، exports
│   ├── messages.lua          الرسائل: إرسال/استلام/قراءة/حذف/قائمة المحادثات + عدّاد غير المقروء
│   ├── calls.lua             آلة حالات المكالمات كاملة + سجل المكالمات + 911
│   ├── contacts.lua          CRUD لجهات الاتصال + مفضلة + بحث
│   ├── bank.lua              الرصيد والتحويلات والعمليات المعلقة (أوفلاين) — عبر hooks قابلة للاستبدال
│   ├── assets.lua            المركبات (تسجيل/قفل/محرك/GPS + تتبع الموضع) + العقارات + الوظائف
│   └── services.lua          الملاحظات، المتجر، إعدادات الملف الشخصي، معلومات السيرفر، الطوارئ
│
├── client/
│   ├── theme.lua             نظام الألوان الكامل (dark/light) — بدّل الألوان من هنا
│   ├── main.lua              حالة Phone، registerPhoneApp (API التوسعة)، فتح/إغلاق، البطارية، preload للصور
│   ├── input.lua             فأرة (نقر/سحب) + لوحة مفاتيح للحقول + PIN
│   ├── animations.lua        محرك Tween صغير (easing + callbacks)
│   ├── ui_kit.lua            مكتبة المكونات: أزرار، حقول، قوائم virtualized، Modal، Slider، Toggle…
│   ├── ui.lua              الإطار، شريط الحالة، wallpaper، شاشة القفل، Overlay المكالمة، التوجيه بين التطبيقات، waypoint
│   ├── notifications.lua     Toasts + Notification Center + توجيه الرسائل الواردة للمحادثة المفتوحة
│   └── apps/                 كل تطبيق ملف مستقل:
│       ├── home.lua          الشبكة + Dock + badges
│       ├── contacts.lua      جهات الاتصال
│       ├── messages.lua      المحادثات + chat view
│       ├── calls.lua         الكيباد + السجل + معالجات حالة المكالمة
│       ├── bank.lua          البنك
│       ├── maps.lua          الخرائط
│       ├── camera.lua        الكاميرا + ألبوم (Photos)
│       ├── settings.lua      الإعدادات
│       ├── notes.lua         الملاحظات
│       ├── vehicles.lua      المركبات
│       ├── properties.lua    العقارات
│       ├── jobs.lua          الوظائف
│       ├── emergency.lua     الطوارئ
│       ├── store.lua         متجر التطبيقات
│       └── weather.lua       معلومات السيرفر
│
├── assets/
│   ├── icons/                16 أيقونة SVG + PNG (خلفية شفافة) — مصدرها build_assets.py
│   ├── wallpapers/           خلفيتان (PNG بزوايا دائرية مطابقة للشاشة)
│   ├── sounds/               ring / notify / send / click / back (WAV)
│   └── ui/                   textures (rounded.png, circle.png)
│
├── sql/phone.sql             مخطط الجداول (اختياري — السيرفر ينشئها تلقائياً)
└── build_assets.py           سكربت توليد الأيقونات والأصوات والـ textures
```

---

## 3) التثبيت (خطوة بخطوة)

1. **قاعدة البيانات**
   ```sql
   CREATE DATABASE mta_rp CHARACTER SET utf8;
   -- أنشئ مستخدماً له صلاحية SELECT/INSERT/UPDATE/DELETE على المخطط
   ```
   ثم استورد `sql/phone.sql` (أو دع الـ Resource ينشئ الجداول تلقائياً).

2. **الإعداد** — عدّل `shared/config.lua`:
   - `database` (host/name/user/pass/port)
   - `openKey` (زر الفتح، أي اسم مفتاح يدعمه bindKey)
   - `numberPrefix` / `numberLength` (صيغة الأرقام)
   - `poi` (إحداثيات الأماكن على سيرفرك)

3. **النسخ والتشغيل**
   ```
   mods/deathmatch/resources/phone/   ← انسخ المجلد كاملاً هنا
   ```
   ثم من الكونسول: `refresh` ثم `start phone`.

4. **داخل اللعبة:** اضغط `F8` — يظهر رقمك الفريد تلقائياً عند أول دخول.

### اختبار سريع
- أرسل رسالة ولاك من كلاينت آخر (يصل إشعار + صوت + غير مقروء).
- اتصل برقم لاعب متصل: يرن عنده، ارفض/اقبل، راقب السجل والمدة.
- حوّل مالاً من البنك وراقب عملية الإرسال والاستلام والإشعار.

---

## 4) أمثلة Events

### من الكلاينت إلى السيرفر
```lua
triggerServerEvent("phone:msg:send", "0551234567", "مرحباً")
triggerServerEvent("phone:call:start", "0551234567")
triggerServerEvent("phone:call:accept")
triggerServerEvent("phone:bank:transfer", "0559876543", 2500)
triggerServerEvent("phone:contacts:save", "0551234567", "Nadia")
triggerServerEvent("phone:vehicles:action", 12, "lock")   -- gps/lock/unlock/engine
```

### من السيرفر إلى الكلاينت
```lua
-- إشعار عام (يظهر Toast ويُحفظ في مركز الإشعارات)
triggerClientEvent(player, "phone:notify", player, "bank", "Bank", "Received $2,500 from John", "bank")

-- تحديثات جاهزة يستخدمها النظام داخلياً (لازم ألا تُرسل يدوياً إلا عند الحاجة):
triggerClientEvent(player, "phone:toast", player, 1, "OK")
triggerClientEvent(player, "phone:count", player, "msgs", 3)      -- غير مقروء (قيمة مطلقة)
triggerClientEvent(player, "phone:chats:list", player, {...})
triggerClientEvent(player, "phone:call:state", player, "ACTIVE", "0551234567", "Nadia", 0, "")
```

### Exports للتكامل مع موارد أخرى (server-side)
```lua
phoneNotify(player, "City", "تم تفعيل صلاحياتك.", "notifications")
phoneGetNumber(player)                     -- "0551234567" أو nil
phoneSetJob(player, "police")              -- أي id من PhoneConfig.jobs
phoneAddProperty(player, "Villa Palm", "Villa", -167, 115, 20)
-- المركبات: عند Spawn سيارة للاعب من نظامك:
-- (تُربط تلقائياً عندما يدخل اللاعب السيارة عبر onVehicleOccupant إذا كان الرقم المسجل
--  يطابق vehicle id — أو استخدم phoneAddProperty النمط نفسه عبر INSERT على phone_vehicles)
```

---

## 5) إضافة تطبيق جديد (App Framework)

1. في `shared/apps.lua`:
   ```lua
   { id = "music", name = "Music", icon = "assets/icons/music.png", order = 17, desc = "Play music." }
   ```
2. أيقونة في `assets/icons/music.png` (و/أو svg).
3. أنشئ `client/apps/music.lua`:
   ```lua
   registerPhoneApp({
       id = "music",
       name = "Music",
       onOpen = function()
           triggerServerEvent("phone:music:fetch")   -- إن احتجت بيانات من السيرفر
       end,
       render = function()
           K.rrect(0, 0, 360, 740, 0, T.screen)
           K.header("Music")
           K.btn(20, 84, 320, 48, function()
               Sound.play("notify")
           end, { style = "primary", label = "Play" })
       end,
   })
   ```
4. أضف `<script src="client/apps/music.lua" type="client" />` في `meta.xml`.
5. أضفه في `PhoneConfig.enabledApps`.

اكتمل التطبيق: سيظهر في الشاشة الرئيسية وفي المتجر ويمكن إزالته/تثبيته.

---

## 6) الأمان (ماذا يحمي النظام)

- **لا ثقة بالكلاينت:** كل رقم/مبلغ/نص يمر بـ `SEC.number` / `SEC.amount` / `SEC.s` في السيرفر.
- **حقن SQL:** MTA لا يعرض Prepared Statements، لذلك كل السلاسل تمر بـ `dbEscapeString`
  وكل الأرقام عبر `tonumber()` — لا قيمة خارجية تدخل الاستعلام بدون تطهير.
- **Rate Limits:** الرسائل (10/د)، المكالمات (5/د)، التحويلات (20/س)، الطوارئ (5/2د).
- **الملكية:** قفل/محرك المركبة لا يعملان إلا بعد SELECT بالـ `owner_id` المطابق.
- **البنك:** لا تحويل لنفسك، لا سالب، سقف للمبلغ، رصيد يُفحص ويُخصم في السيرفر فقط،
  أوفلاين → `phone_bank_pending` يُرصَد عند الدخول.
- **Audit Log:** كل عملية حساسة تُسجل في الكونسول و`logs/audit_YYYYMM.txt`.

---

## 7) الأداء

- `onClientRender` يعمل **فقط** أثناء فتح الهاتف (zero cost وإلا).
- القوائم **virtualized**: تُرسم الصفوف الظاهرة فقط.
- الصور تُحمّل مرة (dxf) وتُكاشف قبل الرسم (fallback تلقائي).
- الاستعلامات: `LIMIT` في كل مكان، cache لأرقام اللاعبين والوضع غير المقروء في الذاكرة،
  تحديث موضع المركبات بثrottle (كل 10 ثوانٍ للمركبات المشغولة فقط).
- لا يوجد `setTimer` سريع على الكلاينت سوى تحديث البطارية (1ث).

---

## 8) أخطاء محتملة وحلولها

| المشكلة | السبب / الحل |
|---|---|
| `attempt to call global 'export'` في السيرفر | خادمك يعمل على MTA 1.5.9 (دالة export مضافة في 1.6). **أُصلح**: التصدير يعمل الآن على النسختين (globals على 1.5.9 + export() على 1.6) |
| أخطاء `dxGetMousePosition` / `getTickCount` / `dxfCreateImage` على الكلاينت | هذه الدوال غير موجودة في عميلك — الأرجح أنك على **MTA Mobile** (هاتف). واجهة الهاتف تحتاج فأرة = **عميل MTA على PC فقط**. الكود الآن يطبع تحذيراً واحداً بدل مئات الأخطاء |
| `Can't connect to MySQL server on 'localhost:3306' (10061)` | MySQL/MariaDB غير مشغّل على جهاز السيرفر أو بيانات `database` في config خاطئة. شغّل MySQL ثم: `stop phone` + `start phone` |
| `ERROR: cannot connect to database` في الكونسول | بيانات `database` في config خاطئة، أو MySQL غير مشغّل. النظام يعمل بصعوبة بدون DB (لا رسائل/بنك) |
| الزر لا يفتح الهاتف | المفتاح محجوز لمورد آخر → غيّر `openKey` |
| لا تظهر الصور (أيقونات/خلفية) | تأكد أن `assets/*` منسوخة كاملة وأن الـ meta يحتوي file tags |
| الكاميرا لا تلتقط | `screenShotToFile` تتطلب عميل MTA حديث (1.5.9.4604+). سيظهر Toast توضيحي |
| GPS لا يضع بلاب | على MTA القديمة بدون `mapAddBlip` يستخدم `createBlip` كfallback؛ إن لم يعمل فحدّث MTA |
| أيقونة الصوت لا تغيّر مستوى الصوت | MTA لا يوفر API لمستوى الصوت لكل صوت — 0 = كتم، فوقها = تشغيل (موضح في Settings) |
| صوت الرنين مستمر بعد إغلاق الهاتف | لا يحدث عادةً (يُوقف عند close)؛ إن حدث فغلق اللعبة يعيده. أبلغنا إن تكرر |
| عربية في حقل الكتابة | أحداث الإدخال في MTA (onClientChar) تدعم أساساً الأحرف اللاتينية/الأسكي؛ غيّر لغة لوحة المفاتيح لإدخال نص |
| `attempt to index nil` عند فتح تطبيق | غالباً حدث بيانات لم يصل (DB). راجع كونسول السيرفر |

---

## 9) ملاحظات تصميمية

- الواجهة مرسومة بـ **DX** (ليست GUI) — لذلك نستخدم الفأرة الملتقطة داخل شاشة الهاتف فقط،
  ولوحة المفاتيح للتأليف في الحقول (Enter = تأكيد، Backspace = حذف، Escape = إلغاء التركيز).
- التصميم كله ضمن مساحة افتراضية 360×740 تتناسب تلقائياً مع دقة شاشة اللاعب (Responsive).
- الأيقونات SVG مصدرها `build_assets.py` — غيّر الألوان/الرموز وأعد التوليد:
  `python3 build_assets.py`
- الـ Mockups (تصميم الهاتف وشاشة الرسائل) محفوظة كـ SVG في مجلد `preview/` خارجهذا الـ Resource.
