-- ============================================================================
-- AURA Phone - Theme System
-- ============================================================================

PhoneEnv = {
    mouse = type(dxGetMousePosition) == "function",
    dxf   = type(dxfCreateImage) == "function",
    tick  = type(getTickCount) == "function",
}

-- ============================================================================
-- SAFE FUNCTIONS
-- ============================================================================

function safeTickCount()
    if type(getTickCount) == "function" then
        return getTickCount()
    end

    return math.floor(os.time() * 1000)
end

function safeFrameDelta()
    if type(getFrameDelta) == "function" then
        local ok, delta = pcall(getFrameDelta)

        if ok and delta and delta > 0 then
            return delta
        end
    end

    return 16
end

-- ============================================================================
-- THEME PALETTES
-- ============================================================================

ThemePalettes = {

    dark = {

        frame       = { 18, 20, 27, 255 },
        frameEdge   = { 52, 57, 70, 255 },

        screen      = { 13, 15, 21, 255 },

        card        = { 27, 31, 42, 240 },
        cardSoft    = { 38, 43, 57, 235 },

        primary     = { 52, 211, 153, 255 },
        primaryDeep = { 16, 185, 129, 255 },

        text        = { 244, 246, 250, 255 },
        sub         = { 151, 160, 179, 255 },
        faint       = { 98, 106, 126, 255 },

        danger      = { 248, 113, 113, 255 },
        dangerDeep  = { 225, 29, 72, 255 },

        warn        = { 251, 191, 36, 255 },

        success     = { 52, 211, 153, 255 },

        info        = { 96, 165, 250, 255 },

        input       = { 23, 26, 36, 255 },

        border      = { 255, 255, 255, 14 },

        dock        = { 255, 255, 255, 24 },

        toast       = { 25, 28, 38, 248 },

        bubbleMe    = { 34, 197, 94, 255 },

        bubbleThem  = { 36, 43, 59, 255 },

        dim         = { 5, 7, 12, 190 },
    },


    light = {

        frame       = { 18, 20, 27, 255 },
        frameEdge   = { 90, 96, 112, 255 },

        screen      = { 244, 246, 250, 255 },

        card        = { 255, 255, 255, 245 },
        cardSoft    = { 235, 238, 244, 235 },

        primary     = { 5, 150, 105, 255 },
        primaryDeep = { 4, 120, 87, 255 },

        text        = { 27, 31, 42, 255 },
        sub         = { 108, 116, 138, 255 },
        faint       = { 162, 168, 182, 255 },

        danger      = { 220, 68, 68, 255 },
        dangerDeep  = { 190, 40, 60, 255 },

        warn        = { 217, 158, 20, 255 },

        success     = { 5, 150, 105, 255 },

        info        = { 37, 99, 235, 255 },

        input       = { 255, 255, 255, 255 },

        border      = { 20, 25, 40, 22 },

        dock        = { 255, 255, 255, 150 },

        toast       = { 255, 255, 255, 248 },

        bubbleMe    = { 22, 163, 74, 255 },

        bubbleThem  = { 233, 236, 242, 255 },

        dim         = { 30, 34, 48, 170 },
    }
}

-- ============================================================================
-- THEME OBJECT
-- ============================================================================

Theme = Theme or {}

Theme.currentName = "dark"

Theme.current = ThemePalettes.dark

-- IMPORTANT:
-- T is a TABLE, not a function.
T = Theme.current

function Theme.apply(name)

    name = name or "dark"

    if not ThemePalettes[name] then
        name = "dark"
    end

    Theme.currentName = name

    Theme.current = ThemePalettes[name]

    -- Update global T
    T = Theme.current
end

-- ============================================================================
-- COLOR FUNCTION
-- Returns MTA compatible color using tocolor()
-- ============================================================================

function C(color, alpha)

    color = color or { 255, 255, 255, 255 }

    local r = tonumber(color[1]) or 255
    local g = tonumber(color[2]) or 255
    local b = tonumber(color[3]) or 255
    local a = tonumber(alpha)

    if not a then
        a = tonumber(color[4]) or 255
    end

    r = math.max(0, math.min(255, r))
    g = math.max(0, math.min(255, g))
    b = math.max(0, math.min(255, b))
    a = math.max(0, math.min(255, a))

    return tocolor(r, g, b, a)
end

-- ============================================================================
-- COLOR MIX
-- ============================================================================

function mixc(a, b, t)

    a = a or { 255, 255, 255, 255 }
    b = b or { 255, 255, 255, 255 }

    t = tonumber(t) or 0

    if t < 0 then
        t = 0
    elseif t > 1 then
        t = 1
    end

    return {

        math.floor((a[1] or 255) + ((b[1] or 255) - (a[1] or 255)) * t),

        math.floor((a[2] or 255) + ((b[2] or 255) - (a[2] or 255)) * t),

        math.floor((a[3] or 255) + ((b[3] or 255) - (a[3] or 255)) * t),

        math.floor((a[4] or 255) + ((b[4] or 255) - (a[4] or 255)) * t)
    }
end

-- ============================================================================
-- AVATAR COLORS
-- ============================================================================

local AVATAR_COLORS = {

    { 96, 165, 250, 255 },

    { 244, 114, 182, 255 },

    { 52, 211, 153, 255 },

    { 251, 146, 60, 255 },

    { 167, 139, 250, 255 },

    { 45, 212, 191, 255 },

    { 251, 191, 36, 255 },

    { 129, 140, 248, 255 }
}

function avatarColor(name)

    if Utils and Utils.hash then

        local index = Utils.hash(
            tostring(name or "?"),
            #AVATAR_COLORS
        )

        return AVATAR_COLORS[index]
    end

    return AVATAR_COLORS[1]
end