-- ============================================================================
-- AURA Phone - animations (client)
-- Tiny tween engine: named animations, easing, completion callbacks.
-- Everything in the phone (open/close, app switch, toasts, shade) uses this.
-- ============================================================================
Anim = { anims = {} }

local EASE = {
    linear = function(t) return t end,
    outCubic = function(t) return 1 - (1 - t) ^ 3 end,
    inOutCubic = function(t) return t < 0.5 and 4 * t * t * t or 1 - (-2 * t + 2) ^ 3 / 2 end,
    outBack = function(t)
        local c = 1.70158
        return 1 + (c + 1) * (t - 1) ^ 3 + c * (t - 1) ^ 2
    end,
}

--- start (or restart) a named animation
function Anim.play(id, ms, cb, easeName)
    Anim.anims[id] = {
        t = 0,
        dur = math.max(1, ms or 300),
        p = 0,
        cb = cb,
        ease = EASE[easeName or "outCubic"] or EASE.outCubic,
    }
end

function Anim.update()
    for id, a in pairs(Anim.anims) do
        a.t = a.t + safeFrameDelta()
        local p = math.min(1, a.t / a.dur)
        a.p = a.ease(p)
        if p >= 1 then
            Anim.anims[id] = nil
            if a.cb then a.cb() end
        end
    end
end

--- eased progress of a running animation (def when idle)
function Anim.get(id, def)
    local a = Anim.anims[id]
    return a and a.p or def
end

function Anim.active(id)
    return Anim.anims[id] ~= nil
end
