-- ============================================================================
-- AURA Phone - notifications (client)
-- * toast queue (one at a time, slide in/out, auto dismiss)
-- * notification center (shade from the top, recent 30, clear all)
-- * incoming message routing (opens chat if the user is in it)
-- ============================================================================
Notify = {
    list = {},
    queue = {},
    toast = nil,
}

--- push a notification (from the server or locally)
function Notify.push(icon, title, msg, cat)
    table.insert(Notify.list, 1, { icon = icon or "notifications", title = title or "Notification", msg = msg or "", t = os.time() })
    if #Notify.list > 30 then table.remove(Notify.list) end
    table.insert(Notify.queue, { icon = icon or "notifications", title = title or "Notification", msg = msg or "", cat = cat or "messages", born = safeTickCount() })
    if #Notify.queue > 8 then table.remove(Notify.queue) end
    -- sound only while the phone is open and the category is allowed
    if Phone.open and not Phone.closing and Phone.notifsEnabled[cat or "messages"] ~= false then
        Sound.play("notify")
    end
end

addEvent("phone:notify", true)
addEventHandler("phone:notify", root, function(icon, title, msg, cat)
    Notify.push(icon, title, msg, cat or "messages")
end)

--- called every frame from the render loop
function Notify.update()
    if not Phone.toast then
        local next = table.remove(Notify.queue, 1)
        if next and Phone.open and not Phone.closing and not Phone.locked then
            Phone.toast = next
        end
        return
    end
    local age = safeTickCount() - Phone.toast.born
    if age > 3600 then
        Phone.toast = nil
    end
end

--- toast visual (top of the screen)
function Notify.renderToasts()
    Notify.update()
    local t = Phone.toast
    if not t then return end
    local age = safeTickCount() - t.born
    local p
    if age < 260 then
        p = age / 260
    elseif age > 3200 then
        p = 1
    else
        p = 1
    end
    local ease = 1 - (1 - p) * (1 - p)
    local y = -92 + ease * 92
    local x, yy, w, h = Phone.vp(10, y, 340, 62)
    dxDrawRectangle(x, yy, w, h, C(T.toast))
    -- left accent
    dxDrawRectangle(x, yy, 3, h, C(T.primary))
    local ic = Phone.appRegistry[t.icon]
    K.icon(ic and ic.icon and Phone.img[ic.icon] or Phone.img["assets/icons/notifications.png"], 20, y + 10, 40)
    K.text(t.title, 72, y + 9, { size = 12.5, bold = true, w = 270, h = 20 })
    if t.msg and t.msg ~= "" then
        K.text(t.msg, 72, y + 31, { size = 10.5, color = T.sub, w = 270, h = 22, wrap = true })
    end
    -- tap to dismiss
    K.register(10, y, 340, 62, function()
        Phone.toast = nil
    end)
end

--- notification center (shade)
function Notify.renderShade()
    local p = Anim.get("shade", 1)
    local h = 430 * p
    if h <= 2 then return end
    K.rrect(0, 0, 360, h, 0, { 10, 12, 18, 245 })
    K.rrect(0, h - 14, 360, 14, 8, { 10, 12, 18, 245 })
    K.text("Notifications", 24, 18, { size = 15, bold = true })
    K.text("Clear", 268, 14, { size = 11.5, valign = "middle", color = T.primary, w = 68, h = 22 })
    K.register(268, 12, 68, 26, function()
        Notify.list = {}
        Sound.play("back")
    end)
    if #Notify.list == 0 then
        K.empty("No recent notifications", 0, 120, 360)
    else
        local i = 0
        local top = 52
        for _, n in ipairs(Notify.list) do
            if top + 56 > h - 16 then break end
            i = i + 1
            local ic = Phone.appRegistry[n.icon]
            K.icon(ic and ic.icon and Phone.img[ic.icon] or Phone.img["assets/icons/notifications.png"], 20, top + 10, 34)
            K.text(n.title, 66, top + 6, { size = 11.5, bold = true, w = 270, h = 18 })
            if n.msg and n.msg ~= "" then
                K.text(n.msg, 66, top + 25, { size = 10, color = T.sub, w = 270, h = 18, wrap = true })
            end
            K.text(Utils.timeAgo(n.t), 288, top + 6, { size = 9.5, color = T.faint, w = 52, align = "right", h = 16 })
            top = top + 62
            if i >= 6 then break end
        end
    end
    K.text("Tap outside to close", 0, h - 44, { w = 360, size = 10, align = "center", color = T.faint })
    -- close zone (the whole screen below the shade)
    K.register(0, h + 14, 360, 740 - h, function()
        Phone.shade = false
        Anim.play("shade", PhoneConfig.animations.shade)
        Sound.play("back")
    end)
    -- tap the shade itself does nothing (so Clear/list work)
end

-- ---------------------------------------------------------------------------
-- routing: incoming message while viewing that thread -> append locally
-- ---------------------------------------------------------------------------
addEvent("phone:msg:new", true)
addEventHandler("phone:msg:new", root, function(from, name, text, time)
    Notify.push("messages", name or from, text, "messages")
    Phone.data.unreadMsgs = Phone.data.unreadMsgs + 1
    -- if the user is inside this exact conversation, live-append it
    local msgsApp = Phone.appRegistry and Phone.appRegistry["messages"]
    if msgsApp and msgsApp.onIncoming and Phone.app == "messages" then
        msgsApp.onIncoming(from, name, text, time)
    end
end)

addEvent("phone:msg:echo", true)
addEventHandler("phone:msg:echo", root, function(number, text, time)
    local msgsApp = Phone.appRegistry and Phone.appRegistry["messages"]
    if msgsApp and msgsApp.onEcho and Phone.app == "messages" then
        msgsApp.onEcho(number, text, time)
    end
end)
