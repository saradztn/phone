-- ============================================================================
-- AURA Phone - client core
-- * global Phone state, app registry (registerPhoneApp API)
-- * open/close with animation, battery simulation, image preloading
-- * the single onClientRender entry point -> renderPhone() (ui.lua)
-- ============================================================================
Phone = {
    open = false,
    closing = false,
    anim = 0,
    app = "home",
    appAnim = 0,

    -- geometry (screen pixels), recomputed every frame
    x = 0, y = 0, W = 0, H = 0, S = 1, bez = 6,
    sx = 0, sy = 0, sw = 0, sh = 0,
    vx = 360, vy = 740,          -- virtual design space

    number = "",
    pkey = "",
    playerName = "",
    battery = PhoneConfig.battery.start,

    locked = false,
    pinInput = "",
    shade = false,
    call = nil,                  -- active / incoming call overlay state
    toast = nil,                 -- current toast

    settings = {
        theme = "dark",
        wallpaper = 1,           -- 0 = gradient fallback, 1..n = bundled
        uiScale = 1.0,
        ringVol = 70,
        notifyVol = 70,
        sfxVol = 100,
        phoneName = PhoneConfig.appName,
        pinEnabled = false,
        pin = "",
    },
    notifsEnabled = { messages = true, calls = true, bank = true },

    data = {
        contacts = {},
        chats = {},
        thread = {},
        threadWith = "",
        calllog = {},
        bank = { balance = 0, txns = {} },
        notes = {},
        vehicles = {},
        properties = {},
        jobs = nil,
        serverInfo = nil,
        store = {},
        installed = {},
        unreadMsgs = 0,
        unreadCalls = 0,
        waypoint = nil,
        photos = {},
    },

    img = {},
    lowBatteryWarned = false,
}

-- ---------------------------------------------------------------------------
-- app registry (the extension API)
-- ---------------------------------------------------------------------------
local AppRegistry = {}
function registerPhoneApp(def)
    if type(def) ~= "table" or not def.id or not def.render then
        error("registerPhoneApp: expected { id, render = function() ... }", 2)
    end
    def.name = def.name or def.id
    def.icon = def.icon or ("assets/icons/" .. def.id .. ".png")
    AppRegistry[def.id] = def
end
Phone.appRegistry = AppRegistry

-- ---------------------------------------------------------------------------
-- sounds
-- ---------------------------------------------------------------------------
Sound = { id = nil }
--- play a sound; returns the sound id (or nil). Volume 0 mutes.
function Sound.play(name)
    local file = PhoneConfig.sounds[name]
    if not file then return end
    local vol
    if name == "ring" then vol = Phone.settings.ringVol
    elseif name == "notify" or name == "send" then vol = Phone.settings.notifyVol
    else vol = Phone.settings.sfxVol end
    if not vol or vol <= 0 then return nil end  -- MTA has no per-sound volume API: 0 = mute
    if Sound.id then stopClientSound(Sound.id) end
    local id = playClientSound(resourceRoot, file, name == "ring")
    Sound.id = id
    return id
end

-- ---------------------------------------------------------------------------
-- open / close
-- ---------------------------------------------------------------------------
local function openPhone()
    if Phone.open or Phone.closing then return end
    Phone.open = true
    Phone.anim = 0
    Anim.play("open", PhoneConfig.animations.open)
    guiSetInputEnabled(false)
    showCursor(true)
end

local function closePhone()
    if not Phone.open or Phone.closing then return end
    Phone.closing = true
    Phone.shade = false
    if Phone.call then
        if Phone.call.soundId then stopClientSound(Phone.call.soundId) end
        Phone.call = nil
    end
    Input.reset()
    Anim.play("close", PhoneConfig.animations.close, function()
        Phone.open, Phone.closing = false
        Phone.anim = 0
        Phone.app = "home"
        pcall(guiSetInputEnabled, true)
        if type(showCursor) == "function" then showCursor(false) end
    end)
end

local keyOk = bindKey(PhoneConfig.openKey, "down", function()
    if Phone.open and not Phone.closing then closePhone() else openPhone() end
end)
if not keyOk then
    outputDebugString("[phone] Could not bind open key '" .. tostring(PhoneConfig.openKey) .. "' (in use). Change PhoneConfig.openKey.")
end

-- close on death
addEventHandler("onClientWasted", localPlayer, function()
    if Phone.open and not Phone.closing then closePhone() end
end)

-- ---------------------------------------------------------------------------
-- battery simulation (slow drain while open, "fast charge" at 0)
-- ---------------------------------------------------------------------------
setTimer(function()
    if not Phone.open or Phone.closing then return end
    local b = Phone.battery
    if b > 0 then
        b = b - PhoneConfig.battery.drainPerMin / 60
        if b < 0 then b = 0 end
        if b <= 15 and not Phone.lowBatteryWarned then
            Phone.lowBatteryWarned = true
            Notify.push("notifications", "Low battery", "Battery below 15% — charging…")
        end
    else
        b = math.min(100, b + PhoneConfig.battery.chargePerMin / 60)
        if b >= 100 then Phone.lowBatteryWarned = false end
    end
    Phone.battery = b
end, 1000, 0)

-- ---------------------------------------------------------------------------
-- handshake from server
-- ---------------------------------------------------------------------------
addEvent("phone:settings:load", true)
addEventHandler("phone:settings:load", root, function(settings)
    for k, v in pairs(settings or {}) do
        if k == "phoneName" then Phone.settings.phoneName = tostring(v)
        elseif k == "pin" then Phone.settings.pin = tostring(v)
        elseif k == "pinEnabled" then Phone.settings.pinEnabled = (v == "1" or v == 1) end
    end
    if Phone.settings.pinEnabled then Phone.locked = true end
    Phone.pinInput = ""
end)

addEvent("phone:apps:load", true)
addEventHandler("phone:apps:load", root, function(installed)
    Phone.data.installed = installed or {}
end)

addEvent("phone:count", true)
addEventHandler("phone:count", root, function(field, value)
    if field == "msgs" then Phone.data.unreadMsgs = math.max(0, math.floor(tonumber(value) or 0))
    elseif field == "calls" then Phone.data.unreadCalls = Phone.data.unreadCalls + math.max(0, math.floor(tonumber(value) or 0)) end
end)

-- generic toast from the server
addEvent("phone:toast", true)
addEventHandler("phone:toast", root, function(ok, text)
    Notify.push(ok and "notifications" or "notifications", ok and "OK" or "Error", text or "")
end)

-- ---------------------------------------------------------------------------
-- preload images
-- ---------------------------------------------------------------------------
local function preloadImages()
    if not PhoneEnv.dxf then return end
    for _, app in pairs(AppRegistry) do
        Phone.img[app.icon] = dxfCreateImage(app.icon)
    end
    for i, path in ipairs(PhoneConfig.wallpapers) do
        Phone.img["wp" .. i] = dxfCreateImage(path)
    end
    Phone.img.rounded = dxfCreateImage("assets/ui/rounded.png")
    Phone.img.circle = dxfCreateImage("assets/ui/circle.png")
end
addEventHandler("onClientResourceStart", resourceRoot, function()
    local missing = {}
    if not PhoneEnv.mouse then missing[#missing + 1] = "mouse API" end
    if not PhoneEnv.dxf then missing[#missing + 1] = "dxfCreateImage" end
    if not PhoneEnv.tick then missing[#missing + 1] = "getTickCount" end
    if #missing > 0 then
        outputDebugString("[phone] WARNING: this client is missing " .. table.concat(missing, ", ") ..
            " - the phone UI cannot work on it (a standard PC MTA client is required).")
    end
    preloadImages()
end)

addEventHandler("onClientResourceStop", resourceRoot, function()
    if Sound.id then stopClientSound(Sound.id) end
    if Phone.call and Phone.call.soundId then stopClientSound(Phone.call.soundId) end
    guiSetInputEnabled(true)
    showCursor(false)
    Phone.open, Phone.closing = false, false
end)

-- ---------------------------------------------------------------------------
-- the single render entry point
-- ---------------------------------------------------------------------------
addEventHandler("onClientRender", root, function()
    if not Phone.open and not Phone.closing and not Anim.active("open") then
        return  -- phone fully closed: zero render cost
    end
    Input.update()
    Anim.update()
    if Phone.closing then
        Phone.anim = 1 - Anim.get("close", 0)
    elseif Phone.open then
        Phone.anim = Anim.get("open", 1)
    else
        Phone.anim = Anim.get("open", 0)
    end
    if Phone.anim > 0 then
        renderPhone()
    end
end)
