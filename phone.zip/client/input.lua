-- ============================================================================
-- AURA Phone - input (client)
-- * mouse capture inside the phone screen (click / drag)
-- * keyboard capture for focused fields (chars, enter, backspace, escape)
-- * drag-to-scroll targets for K.list
-- ============================================================================
Input = {
    mx = 0, my = 0,
    inside = false,
    down = false,
    downAt = nil,
    moved = false,
    pending = nil,      -- click waiting to be consumed by the frame's zones
    focus = nil,        -- id of focused field
    buf = "",           -- buffer of the focused field
    dragTarget = nil,   -- list id being dragged
    dragLastY = 0,
}

function Input.reset()
    Input.down = false
    Input.downAt = nil
    Input.moved = false
    Input.pending = nil
    Input.focus = nil
    Input.buf = ""
    Input.dragTarget = nil
end

-- dxGetMouseState: 1 = left click, 2 = left down, 3/4 = right, 5/6 = wheel
local function leftDown(state)
    return state == 1 or state == 2
end

function Input.update()
    if not Phone.open or Phone.closing then return end
    if not PhoneEnv.mouse then return end  -- e.g. MTA Mobile: no mouse API
    local x, y = dxGetMousePosition()
    Input.mx, Input.my = x, y
    Input.inside = x >= Phone.sx and x <= Phone.sx + Phone.sw and y >= Phone.sy and y <= Phone.sy + Phone.sh
    showCursor(Input.inside)

    local state = dxGetMouseState()
    local isDown = leftDown(state)
    local wasDown = Input.down
    Input.down = isDown

    if isDown and not wasDown then
        if Input.inside then
            Input.downAt = { x = x, y = y }
            Input.moved = false
            Input.dragTarget = K.listTargetAt(x, y)
            Input.dragLastY = y
        end
    elseif not isDown and wasDown then
        if Input.downAt and not Input.moved then
            Input.pending = { x = Input.downAt.x, y = Input.downAt.y }
        end
        Input.downAt = nil
        Input.dragTarget = nil
    elseif isDown and Input.downAt then
        if math.abs(x - Input.downAt.x) + math.abs(y - Input.downAt.y) > 9 then
            Input.moved = true
        end
        -- drag scrolling
        if Input.moved and Input.dragTarget then
            local sc = K.sc[Input.dragTarget]
            if sc then
                sc.off = sc.off - (y - Input.dragLastY)
            end
            Input.dragLastY = y
        end
    end
end

--- called after all zones of the frame were registered; the topmost
--- zone under the pending click receives it.
function Input.consumeClick()
    local c = Input.pending
    Input.pending = nil
    if not c then return end
    for i = #K.zones, 1, -1 do
        local z = K.zones[i]
        if c.x >= z.x and c.x <= z.x + z.w and c.y >= z.y and c.y <= z.y + z.h then
            if z.cb then z.cb() end
            return
        end
    end
end

-- ---------------------------------------------------------------------------
-- keyboard
-- ---------------------------------------------------------------------------
addEventHandler("onClientChar", root, function(char, code, extended)
    if not Phone.open or Phone.closing or not Input.focus then return end
    local spec = K.fieldSpec[Input.focus]
    if not spec or #char ~= 1 then return end
    if spec.digits and not char:match("%d") then return end
    if spec.alnum and not char:match("[%w@._- ]") then return end
    if #Input.buf >= (spec.max or 64) then return end
    Input.buf = Input.buf .. char
    if spec.onEdit then spec.onEdit(Input.buf) end
end)

addEventHandler("onClientKey", root, function(key, pressed, state)
    if not Phone.open or Phone.closing then return end
    if not pressed then return end
    if key == "return" and Input.focus then
        local spec = K.fieldSpec[Input.focus]
        local v = Input.buf
        Input.buf = ""
        Input.focus = nil
        if spec and spec.onSubmit then spec.onSubmit(v) end
        return true
    end
    if key == "backspace" and Input.focus then
        Input.buf = Input.buf:sub(1, -2)
        local spec = K.fieldSpec[Input.focus]
        if spec and spec.onEdit then spec.onEdit(Input.buf) end
        return true
    end
    if key == "escape" and Input.focus then
        Input.focus = nil
        Input.buf = ""
        return true
    end
    -- PIN pad digits while locked (no physical field involved)
    if Phone.locked and Phone.settings.pinEnabled and key:match("^%d$") then
        Phone.pinInput = Phone.pinInput .. key
        if #Phone.pinInput == 4 then
            local ok = Phone.pinInput == Phone.settings.pin
            Sound.play(ok and "click" or "back")
            if ok then
                Phone.locked = false
            end
            Phone.pinInput = ""
        end
        return true
    end
end)
