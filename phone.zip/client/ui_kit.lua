-- ============================================================================
-- AURA Phone - UI Kit (Client)
-- Compatible with MTA:SA DX
-- Virtual design space: 360 x 740
-- ============================================================================

K = {
    zones = {},
    listRects = {},
    sc = {},
    fieldSpec = {}
}


-- ============================================================================
-- Safety helpers
-- ============================================================================

local function validNumber(v, fallback)
    v = tonumber(v)

    if not v then
        return fallback or 0
    end

    return v
end


local function getThemeColor(color)

    if type(color) == "table" then
        return color
    end

    return {255, 255, 255, 255}
end


local function getColor(color, alpha)

    color = getThemeColor(color)

    local r = tonumber(color[1]) or 255
    local g = tonumber(color[2]) or 255
    local b = tonumber(color[3]) or 255
    local a = tonumber(alpha)

    if not a then
        a = tonumber(color[4]) or 255
    end

    return tocolor(r, g, b, a)
end


-- ============================================================================
-- Begin frame
-- ============================================================================

function K.begin()

    K.zones = {}
    K.listRects = {}

end


-- ============================================================================
-- Hit zones
-- ============================================================================

function K.registerScreen(x, y, w, h, cb)

    table.insert(K.zones, {
        x = validNumber(x),
        y = validNumber(y),
        w = validNumber(w),
        h = validNumber(h),
        cb = cb
    })

end


function K.register(vx, vy, vw, vh, cb)

    if not Phone or type(Phone.vp) ~= "function" then
        return
    end

    local x, y, w, h =
        Phone.vp(vx, vy, vw, vh)

    K.registerScreen(
        x,
        y,
        w,
        h,
        cb
    )

end


-- ============================================================================
-- Hover
-- ============================================================================

function K.hovering(vx, vy, vw, vh)

    if not Phone or type(Phone.vp) ~= "function" then
        return false
    end

    if not Input then
        return false
    end

    local x, y, w, h =
        Phone.vp(vx, vy, vw, vh)

    local mx =
        tonumber(Input.mx) or -99999

    local my =
        tonumber(Input.my) or -99999

    return (
        mx >= x
        and mx <= x + w
        and my >= y
        and my <= y + h
    )

end


-- ============================================================================
-- List target
-- ============================================================================

function K.listTargetAt(mx, my)

    for id, rect in pairs(K.listRects) do

        if
            mx >= rect.x
            and mx <= rect.x + rect.w
            and my >= rect.y
            and my <= rect.y + rect.h
        then

            return id

        end

    end

    return nil

end


-- ============================================================================
-- Rounded rectangle
-- ============================================================================

function K.rrect(vx, vy, vw, vh, radius, color, alpha)

    if not Phone or type(Phone.vp) ~= "function" then
        return
    end

    local x, y, w, h =
        Phone.vp(vx, vy, vw, vh)

    x = validNumber(x)
    y = validNumber(y)
    w = validNumber(w)
    h = validNumber(h)

    if w <= 0 or h <= 0 then
        return
    end

    radius =
        validNumber(radius) * (Phone.S or 1)

    radius =
        math.min(
            radius,
            w / 2,
            h / 2
        )

    local col =
        getColor(color, alpha)

    -- Normal rectangle
    if radius <= 1 then

        dxDrawRectangle(
            x,
            y,
            w,
            h,
            col
        )

        return

    end

    -- Center horizontal
    dxDrawRectangle(
        x + radius,
        y,
        w - radius * 2,
        h,
        col
    )

    -- Center vertical
    dxDrawRectangle(
        x,
        y + radius,
        w,
        h - radius * 2,
        col
    )

    -- Fallback corners
    -- Using rectangles because DX has no native rounded rectangle.

    dxDrawRectangle(
        x,
        y + radius,
        radius,
        h - radius * 2,
        col
    )

    dxDrawRectangle(
        x + w - radius,
        y + radius,
        radius,
        h - radius * 2,
        col
    )

    -- If circle texture exists
    local img = nil

    if Phone.img then
        img = Phone.img.circle
    end

    local validImage = false

    if
        img
        and type(dxfGetImageWidth) == "function"
    then

        local ok, imageWidth =
            pcall(dxfGetImageWidth, img)

        validImage =
            ok
            and imageWidth
            and imageWidth > 0

    end

    if validImage then

        local size =
            radius * 2

        dxDrawImage(
            img,
            x,
            y,
            size,
            size,
            0,
            0,
            0,
            col
        )

        dxDrawImage(
            img,
            x + w - size,
            y,
            size,
            size,
            0,
            0,
            0,
            col
        )

        dxDrawImage(
            img,
            x,
            y + h - size,
            size,
            size,
            0,
            0,
            0,
            col
        )

        dxDrawImage(
            img,
            x + w - size,
            y + h - size,
            size,
            size,
            0,
            0,
            0,
            col
        )

    else

        -- Safe fallback
        dxDrawRectangle(
            x,
            y,
            radius,
            radius,
            col
        )

        dxDrawRectangle(
            x + w - radius,
            y,
            radius,
            radius,
            col
        )

        dxDrawRectangle(
            x,
            y + h - radius,
            radius,
            radius,
            col
        )

        dxDrawRectangle(
            x + w - radius,
            y + h - radius,
            radius,
            radius,
            col
        )

    end

end


-- ============================================================================
-- Text
-- ============================================================================

function K.text(text, vx, vy, options)

    options = options or {}

    if not Phone or type(Phone.vp) ~= "function" then
        return
    end

    local x, y, w, h

    if options.w and options.h then

        x, y, w, h =
            Phone.vp(
                vx,
                vy,
                options.w,
                options.h
            )

    else

        x, y =
            Phone.vp(vx, vy, 1, 1)

        w = 1
        h = 1

    end

    local scale =
        (options.size or 14)
        * (Phone.S or 1)

    local alignX = "left"

    if options.align == "center" then
        alignX = "center"

    elseif options.align == "right" then
        alignX = "right"
    end

    local alignY = "top"

    if options.valign == "middle" then
        alignY = "center"

    elseif options.valign == "bottom" then
        alignY = "bottom"
    end

    local themeText =
        T and T.text
        or {255, 255, 255, 255}

    local col =
        getColor(
            options.color or themeText,
            options.alpha
        )

    dxDrawText(
        tostring(text or ""),
        x,
        y,
        x + w,
        y + h,
        col,
        scale,
        options.font or "default",
        alignX,
        alignY,
        false,
        options.wrap == true,
        false,
        options.coded == true
    )

end


-- ============================================================================
-- Icon
-- ============================================================================

function K.icon(img, vx, vy, size, alpha)

    if not img then
        return
    end

    if type(dxfGetImageWidth) ~= "function" then
        return
    end

    local ok, width =
        pcall(dxfGetImageWidth, img)

    if not ok or not width or width <= 0 then
        return
    end

    local x, y, w, h =
        Phone.vp(
            vx,
            vy,
            size,
            size
        )

    dxDrawImage(
        img,
        x,
        y,
        w,
        h,
        0,
        0,
        0,
        tocolor(
            255,
            255,
            255,
            alpha or 255
        )
    )

end


-- ============================================================================
-- Star
-- ============================================================================

function K.star(vcx, vcy, radius, color, alpha)

    local x, y =
        Phone.vp(
            vcx,
            vcy,
            1,
            1
        )

    radius =
        validNumber(radius)
        * (Phone.S or 1)

    local col =
        getColor(color, alpha)

    local points = {}

    for i = 0, 9 do

        local angle =
            math.rad(
                -90 + i * 36
            )

        local currentRadius

        if i % 2 == 0 then
            currentRadius = radius
        else
            currentRadius = radius * 0.45
        end

        points[i + 1] = {
            x =
                x
                + math.cos(angle)
                * currentRadius,

            y =
                y
                + math.sin(angle)
                * currentRadius
        }

    end

    for i = 1, 10 do

        local p1 =
            points[i]

        local p2 =
            points[
                i % 10 + 1
            ]

        dxDrawLine(
            p1.x,
            p1.y,
            p2.x,
            p2.y,
            col,
            2
        )

    end

end


-- ============================================================================
-- Button styles
-- ============================================================================

local BTN_STYLES = nil
local BTN_THEME = nil


local function btnStyle(name)

    local currentTheme =
        Phone
        and Phone.settings
        and Phone.settings.theme
        or "dark"

    if BTN_THEME ~= currentTheme then

        BTN_STYLES = {

            primary =
                T.primary,

            danger =
                T.danger,

            success =
                T.success,

            info =
                T.info,

            ghost =
                {255, 255, 255, 20},

            card =
                T.cardSoft

        }

        BTN_THEME =
            currentTheme

    end

    return
        BTN_STYLES[name]
        or BTN_STYLES.card

end


-- ============================================================================
-- Button
-- ============================================================================

function K.btn(vx, vy, vw, vh, callback, options)

    options =
        options or {}

    local base =
        options.color
        or btnStyle(
            options.style or "card"
        )

    local hover =
        K.hovering(
            vx,
            vy,
            vw,
            vh
        )

    local col = base

    if hover and type(mixc) == "function" then

        col =
            mixc(
                base,
                {255, 255, 255, 255},
                0.14
            )

    end

    K.rrect(
        vx,
        vy,
        vw,
        vh,
        options.radius
            or math.min(vh / 2, 14),
        col
    )

    if options.label then

        local textColor

        if
            options.style == "card"
            or options.style == "ghost"
        then

            textColor =
                T.text

        else

            textColor =
                {12, 24, 18, 255}

        end

        K.text(
            options.label,
            vx,
            vy,
            {
                w = vw,
                h = vh,

                size =
                    options.size or 13,

                align = "center",
                valign = "middle",

                color =
                    options.textColor
                    or textColor
            }
        )

    end

    K.register(
        vx,
        vy,
        vw,
        vh,

        function()

            if
                Sound
                and type(Sound.play) == "function"
            then

                Sound.play("click")

            end

            if callback then
                callback()
            end

        end
    )

end


-- ============================================================================
-- Avatar
-- ============================================================================

function K.avatar(name, vx, vy, size)

    local col =
        type(avatarColor) == "function"
        and avatarColor(name)
        or {80, 150, 255, 255}

    K.rrect(
        vx,
        vy,
        size,
        size,
        size * 0.26,
        col
    )

    K.text(
        Utils.initials(name),
        vx,
        vy,
        {
            w = size,
            h = size,

            size =
                size * 0.36,

            align = "center",
            valign = "middle",

            color =
                {255, 255, 255, 235}
        }
    )

end


-- ============================================================================
-- Badge
-- ============================================================================

function K.badge(n, vx, vy)

    n =
        tonumber(n) or 0

    if n <= 0 then
        return
    end

    local label

    if n > 99 then
        label = "99+"
    else
        label = tostring(n)
    end

    local w =
        14 + #label * 4.5

    K.rrect(
        vx,
        vy,
        w,
        14,
        7,
        T.danger
    )

    K.text(
        label,
        vx,
        vy,
        {
            w = w,
            h = 14,

            size = 9,

            align = "center",
            valign = "middle",

            color =
                {255, 255, 255, 255}
        }
    )

end


-- ============================================================================
-- Header
-- ============================================================================

function K.header(title, rightFn)

    K.rrect(
        0,
        0,
        360,
        64,
        0,
        T.screen
    )

    K.text(
        title,
        20,
        16,
        {
            size = 17,
            h = 32,
            valign = "middle"
        }
    )

    local bx, by =
        8, 14

    local bw, bh =
        34, 36

    local mx, my =
        Phone.vp(
            bx + bw / 2,
            by + bh / 2,
            1,
            1
        )

    local size =
        7 * Phone.S

    local hover =
        K.hovering(
            bx,
            by,
            bw,
            bh
        )

    local alpha =
        hover and 255 or 210

    local lineColor =
        getColor(
            T.text,
            alpha
        )

    dxDrawLine(
        mx + size * 0.4,
        my - size,
        mx - size * 0.6,
        my,
        lineColor,
        2
    )

    dxDrawLine(
        mx - size * 0.6,
        my,
        mx + size * 0.4,
        my + size,
        lineColor,
        2
    )

    K.register(
        bx,
        by,
        bw,
        bh,
        function()

            if type(goHome) == "function" then
                goHome()
            end

        end
    )

    if rightFn then
        rightFn()
    end

end


-- ============================================================================
-- Field
-- ============================================================================

function K.field(id, vx, vy, vw, vh, options)

    options =
        options or {}

    local focused =
        Input
        and Input.focus == id

    if focused then

        K.rrect(
            vx - 1.5,
            vy - 1.5,
            vw + 3,
            vh + 3,
            vh / 2,
            T.primary,
            90
        )

    end

    K.rrect(
        vx,
        vy,
        vw,
        vh,
        vh / 2,
        T.input
    )

    local value =
        focused
        and (Input.buf or "")
        or ""

    if value == "" then

        K.text(
            options.placeholder or "Type...",
            vx + 14,
            vy,
            {
                h = vh,
                size = 12.5,
                valign = "middle",
                color = T.faint
            }
        )

    else

        K.text(
            value,
            vx + 14,
            vy,
            {
                h = vh,
                size = 12.5,
                valign = "middle",
                color = T.text
            }
        )

    end

    K.register(
        vx,
        vy,
        vw,
        vh,

        function()

            if not Input then
                return
            end

            Input.focus = id
            Input.buf = ""

            K.fieldSpec[id] = {

                max =
                    options.max or 64,

                digits =
                    options.digits,

                alnum =
                    options.alnum,

                onSubmit =
                    options.submit,

                onEdit =
                    options.edit

            }

        end
    )

    return focused

end


-- ============================================================================
-- List
-- ============================================================================

function K.list(
    id,
    vx,
    vy,
    vw,
    vh,
    count,
    rowH,
    drawRow
)

    local scroll =
        K.sc[id]
        or {off = 0}

    K.sc[id] =
        scroll

    local contentH =
        count * rowH

    local maxOff =
        math.max(
            0,
            contentH - vh
        )

    scroll.off =
        Utils.clamp(
            scroll.off,
            0,
            maxOff
        )

    local x, y, w, h =
        Phone.vp(
            vx,
            vy,
            vw,
            vh
        )

    K.listRects[id] = {

        x = x,
        y = y,
        w = w,
        h = h

    }

    if maxOff > 4 then

        local barH =
            math.max(
                28,
                h * h / contentH
            )

        local barY =
            y
            + (scroll.off / maxOff)
            * (h - barH)

        K.rrect(
            vx + vw - 3,
            vy + (barY - y) / Phone.S,
            2,
            barH / Phone.S,
            1,
            {255, 255, 255, 55}
        )

    end

    local startIndex =
        math.max(
            0,
            math.floor(
                scroll.off / rowH
            )
        )

    local endIndex =
        math.min(
            count,
            startIndex
            + math.ceil(vh / rowH)
            + 1
        )

    for i = startIndex, endIndex - 1 do

        drawRow(
            i + 1,
            vy
            + (i * rowH - scroll.off)
        )

    end

end


-- ============================================================================
-- Scroll bottom
-- ============================================================================

function K.scrollToBottom(
    id,
    vh,
    count,
    rowH
)

    local scroll =
        K.sc[id]
        or {off = 0}

    K.sc[id] =
        scroll

    scroll.off =
        math.max(
            0,
            count * rowH - vh
        )

end


-- ============================================================================
-- Toggle
-- ============================================================================

function K.toggle(
    vx,
    vy,
    vw,
    vh,
    state,
    callback
)

    local track

    if state then
        track = T.primary
    else
        track = {80, 88, 108, 255}
    end

    K.rrect(
        vx,
        vy,
        vw,
        vh,
        vh / 2,
        track
    )

    local knobX

    if state then
        knobX =
            vx + vw - vh + 3
    else
        knobX =
            vx + 3
    end

    K.rrect(
        knobX,
        vy + 3,
        vh - 6,
        vh - 6,
        (vh - 6) / 2,
        {255, 255, 255, 255}
    )

    K.register(
        vx - 4,
        vy - 4,
        vw + 8,
        vh + 8,

        function()

            if
                Sound
                and type(Sound.play) == "function"
            then
                Sound.play("click")
            end

            if callback then
                callback(not state)
            end

        end
    )

end


-- ============================================================================
-- Slider
-- ============================================================================

function K.slider(
    id,
    vx,
    vy,
    vw,
    value,
    options,
    callback
)

    options =
        options or {}

    local min =
        tonumber(options.min)
        or 0

    local max =
        tonumber(options.max)
        or 100

    if max <= min then
        max = min + 1
    end

    value =
        tonumber(value)
        or min

    K.rrect(
        vx,
        vy + 8,
        vw,
        6,
        3,
        {80, 88, 108, 120}
    )

    local progress =
        Utils.clamp(
            (value - min)
            / (max - min),
            0,
            1
        )

    if progress > 0 then

        K.rrect(
            vx,
            vy + 8,
            vw * progress,
            6,
            3,
            T.primary
        )

    end

    local knobX =
        vx + vw * progress

    K.rrect(
        knobX - 8,
        vy + 2,
        16,
        18,
        8,
        {255, 255, 255, 255}
    )

    K.register(
        vx - 10,
        vy - 6,
        vw + 20,
        30,

        function()

            if not callback then
                return
            end

            local mouseX =
                Input
                and (
                    Input.downAt
                    and Input.downAt.x
                    or Input.mx
                )
                or 0

            local screenX, _, screenW =
                Phone.vp(
                    vx,
                    vy,
                    vw
                )

            if not screenW
                or screenW <= 0
            then
                return
            end

            local progress2 =
                Utils.clamp(
                    (mouseX - screenX)
                    / screenW,
                    0,
                    1
                )

            local newValue =
                min
                + progress2
                * (max - min)

            if options.step then

                newValue =
                    math.floor(
                        newValue
                        / options.step
                        + 0.5
                    )
                    * options.step

            end

            callback(
                Utils.clamp(
                    newValue,
                    min,
                    max
                )
            )

        end
    )

end


-- ============================================================================
-- Row
-- ============================================================================

function K.row(
    vx,
    vy,
    vw,
    vh,
    callback,
    color
)

    K.rrect(
        vx,
        vy,
        vw,
        vh,
        14,
        color or T.card
    )

    if callback then

        K.register(
            vx,
            vy,
            vw,
            vh,
            callback
        )

    end

end


-- ============================================================================
-- Modal
-- ============================================================================

function K.modal(
    title,
    drawFn,
    modalHeight
)

    K.rrect(
        0,
        0,
        360,
        740,
        0,
        T.dim
    )

    local modalWidth =
        316

    local height =
        modalHeight
        or 280

    local vx =
        (360 - modalWidth) / 2

    local vy =
        (740 - height) / 2

    K.rrect(
        vx,
        vy,
        modalWidth,
        height,
        18,
        T.card
    )

    K.text(
        title,
        vx + 20,
        vy + 16,
        {
            size = 15
        }
    )

    if drawFn then

        drawFn(
            vx,
            vy,
            modalWidth,
            height
        )

    end

end


-- ============================================================================
-- Empty state
-- ============================================================================

function K.empty(
    message,
    vx,
    vy,
    vw
)

    K.text(
        message,
        vx,
        vy,
        {
            w = vw,
            h = 60,

            size = 12,

            align = "center",
            valign = "middle",

            color = T.faint,

            wrap = true
        }
    )

end


-- ============================================================================
-- Spinner
-- ============================================================================

function K.spinner(
    vx,
    vy,
    size
)

    local tick =
        type(safeTickCount) == "function"
        and safeTickCount()
        or getTickCount()

    for i = 0, 2 do

        local phase =
            math.sin(
                (tick / 300)
                + i * 0.9
            )

        local alpha =
            90 + phase * 110

        K.rrect(
            vx + i * 12,
            vy + 4 + phase * 2,
            6,
            6,
            3,
            {255, 255, 255, alpha}
        )

    end

end


-- ============================================================================
-- Progress
-- ============================================================================

function K.progress(
    vx,
    vy,
    vw,
    vh,
    value,
    color
)

    K.rrect(
        vx,
        vy,
        vw,
        vh,
        vh / 2,
        {80, 88, 108, 100}
    )

    local progress =
        Utils.clamp(
            value or 0,
            0,
            1
        )

    if progress > 0.02 then

        K.rrect(
            vx,
            vy,
            vw * progress,
            vh,
            vh / 2,
            color or T.primary
        )

    end

end