-- ============================================================================
-- AURA Phone - UI Core (client)
-- Fixed geometry / stable virtual coordinate system
-- Virtual resolution: 360 x 740
-- ============================================================================

-- ============================================================================
-- SAFETY
-- ============================================================================

Phone = Phone or {}

Phone.vx = Phone.vx or 360
Phone.vy = Phone.vy or 740

Phone.app = Phone.app or "home"
Phone.anim = Phone.anim or 0
Phone.locked = Phone.locked or false
Phone.shade = Phone.shade or false
Phone.call = Phone.call or nil

Phone.settings = Phone.settings or {}
Phone.settings.uiScale = Phone.settings.uiScale or 1
Phone.settings.theme = Phone.settings.theme or "dark"
Phone.settings.wallpaper = Phone.settings.wallpaper or 0

Phone.img = Phone.img or {}
Phone.appRegistry = Phone.appRegistry or {}
Phone.data = Phone.data or {}

Phone.data.unreadMsgs = Phone.data.unreadMsgs or 0
Phone.data.unreadCalls = Phone.data.unreadCalls or 0


-- ============================================================================
-- PHONE GEOMETRY
-- ============================================================================

local function updatePhoneRect()

    local sw, sh = guiGetScreenSize()

    local VIRTUAL_W = Phone.vx
    local VIRTUAL_H = Phone.vy

    -- Device size
    local H = sh * 0.88
    local W = H * (VIRTUAL_W / VIRTUAL_H)

    -- Prevent too wide phone
    if W > sw * 0.70 then
        W = sw * 0.70
        H = W * (VIRTUAL_H / VIRTUAL_W)
    end

    Phone.W = W
    Phone.H = H

    -- Center device
    Phone.x = (sw - W) / 2
    Phone.y = (sh - H) / 2

    -- Phone frame bezel
    Phone.bez = math.max(4, H * 0.012)

    -- Inner screen
    Phone.sx = Phone.x + Phone.bez
    Phone.sy = Phone.y + Phone.bez

    Phone.sw = Phone.W - Phone.bez * 2
    Phone.sh = Phone.H - Phone.bez * 2

    -- One stable scale
    Phone.S = Phone.sh / VIRTUAL_H
end


-- ============================================================================
-- VIRTUAL -> SCREEN
-- ============================================================================

function Phone.vp(vx, vy, vw, vh)

    local s = Phone.S or 1

    local x = Phone.sx + vx * s
    local y = Phone.sy + vy * s

    local w = (vw or 0) * s
    local h = (vh or 0) * s

    return x, y, w, h
end


-- ============================================================================
-- APP NAVIGATION
-- ============================================================================

function openApp(id)

    local app = Phone.appRegistry[id]

    if not app then
        return
    end

    if Phone.locked then
        return
    end

    if Phone.app ~= "home" and Sound and Sound.play then
        Sound.play("back")
    end

    Phone.app = id

    if Anim and Anim.play and PhoneConfig and PhoneConfig.animations then
        Anim.play("app", PhoneConfig.animations.app)
    end

    if app.onOpen then
        app.onOpen()
    end
end


function goHome()

    if Phone.app == "home" then
        return
    end

    if Phone.locked then
        return
    end

    local current = Phone.appRegistry[Phone.app]

    if current and current.onClose then
        current.onClose()
    end

    Phone.app = "home"

    if Anim and Anim.play and PhoneConfig and PhoneConfig.animations then
        Anim.play("app", PhoneConfig.animations.app)
    end
end


-- ============================================================================
-- CALL SYSTEM
-- ============================================================================

function Phone.startCall(number, name)

    if Phone.call then
        return
    end

    number = tostring(number or "")

    if not (Utils and Utils.isValidNumber and Utils.isValidNumber(number))
        and number ~= "911" then
        return
    end

    Phone.call = {

        number = number,
        name = name or number,

        state = "CALLING",

        start = safeTickCount()
    }

    if Sound and Sound.play then
        Sound.play("click")
    end

    triggerServerEvent("phone:call:start", localPlayer, number)
end


function Phone.updateCall()

    local call = Phone.call

    if not call then
        return
    end

    if call.state == "ENDED" then

        if not call.clearAt then
            call.clearAt = safeTickCount() + 1600
        end

        if safeTickCount() >= call.clearAt then

            if call.soundId and isElement(call.soundId) then
                stopSound(call.soundId)
            end

            Phone.call = nil
        end
    end
end


-- ============================================================================
-- STATUS BAR
-- ============================================================================

local function drawStatusBar()

    if not K then
        return
    end

    local time = getRealTime()

    K.text(
        Utils.formatClock(time),
        20,
        10,
        {
            size = 12.5,
            h = 18,
            valign = "middle",
            bold = true,
            color = T.text
        }
    )

    local carrier = "AURA"

    if PhoneConfig and PhoneConfig.carrier then
        carrier = PhoneConfig.carrier
    end

    K.text(
        carrier,
        245,
        10,
        {
            size = 9,
            w = 55,
            h = 18,
            align = "right",
            valign = "middle",
            color = T.text,
            alpha = 180
        }
    )

    -- Signal
    local ping = 100

    if type(getPlayerPing) == "function" then
        ping = getPlayerPing(localPlayer) or 100
    end

    local bars = 1

    if ping < 80 then
        bars = 4
    elseif ping < 160 then
        bars = 3
    elseif ping < 300 then
        bars = 2
    end

    for i = 1, 4 do

        local height = 3 + i * 2.2

        local x, y, w, h =
            Phone.vp(
                302 + i * 6,
                24 - height,
                3.4,
                height
            )

        dxDrawRectangle(
            x,
            y,
            w,
            h,
            C(
                T.text,
                i <= bars and 235 or 70
            )
        )
    end

    -- Battery
    local bx = 330
    local by = 14
    local bw = 22
    local bh = 11

    local x, y, w, h =
        Phone.vp(bx, by, bw, bh)

    dxDrawRectangle(
        x,
        y,
        w - 2,
        h,
        C({255, 255, 255, 80})
    )

    local battery = tonumber(Phone.battery) or 100

    local frac = Utils.clamp(
        battery / 100,
        0,
        1
    )

    if frac > 0.02 then

        local color = T.text

        if frac <= 0.15 then
            color = T.danger
        end

        dxDrawRectangle(
            x + 2,
            y + 2,
            (w - 4) * frac,
            h - 4,
            C(color)
        )
    end

    -- Battery terminal
    local tx, ty, tw, th =
        Phone.vp(
            bx + bw,
            by + 3,
            2,
            5
        )

    dxDrawRectangle(
        tx,
        ty,
        tw,
        th,
        C({255, 255, 255, 90})
    )

    -- Notification shade zone
    K.register(
        0,
        0,
        360,
        32,

        function()

            Phone.shade = not Phone.shade

            if Anim and Anim.play
                and PhoneConfig
                and PhoneConfig.animations then

                Anim.play(
                    "shade",
                    PhoneConfig.animations.shade
                )
            end

            if Sound and Sound.play then
                Sound.play("click")
            end
        end
    )
end


-- ============================================================================
-- WALLPAPER
-- ============================================================================

local function drawWallpaper()

    local x, y, w, h =
        Phone.vp(
            0,
            0,
            Phone.vx,
            Phone.vy
        )

    local index =
        Phone.settings.wallpaper or 0

    local image =
        index > 0
        and Phone.img["wp" .. index]

    if image and isElement(image) then

        dxDrawImage(
            x,
            y,
            w,
            h,
            image,
            0,
            0,
            0,
            tocolor(255, 255, 255, 255)
        )

        return
    end

    -- Fallback gradient
    local top =
        {20, 30, 58, 255}

    local bottom =
        {10, 14, 26, 255}

    local bands = 30

    for i = 0, bands - 1 do

        local t =
            i / (bands - 1)

        local color =
            mixc(
                top,
                bottom,
                t
            )

        dxDrawRectangle(
            x,
            y + h * t,
            w,
            h / bands + 1,
            C(color)
        )
    end
end


-- ============================================================================
-- DYNAMIC ISLAND
-- ============================================================================

local function drawDynamicIsland()

    local x, y, w, h =
        Phone.vp(
            128,
            8,
            104,
            22
        )

    if K and K.rrect then

        K.rrect(
            128,
            8,
            104,
            22,
            11,
            {5, 6, 10, 255}
        )
    else

        dxDrawRectangle(
            x,
            y,
            w,
            h,
            C({5, 6, 10, 255})
        )
    end

    local cx, cy, cw, ch =
        Phone.vp(
            214,
            12,
            10,
            10
        )

    dxDrawRectangle(
        cx,
        cy,
        cw,
        ch,
        C({30, 44, 70, 255})
    )
end


-- ============================================================================
-- LOCK SCREEN
-- ============================================================================

local function drawLockScreen()

    local time = getRealTime()

    K.text(
        Utils.formatClock(time),
        0,
        150,
        {
            w = 360,
            h = 80,
            size = 64,
            align = "center",
            valign = "middle",
            bold = true,
            color = {255, 255, 255, 255}
        }
    )

    K.text(
        Utils.formatDateLong(time),
        0,
        232,
        {
            w = 360,
            h = 30,
            size = 14,
            align = "center",
            valign = "middle",
            color = {255, 255, 255, 220}
        }
    )

    if not Phone.settings.pinEnabled then

        K.text(
            "Tap to unlock",
            0,
            640,
            {
                w = 360,
                h = 30,
                size = 12,
                align = "center",
                valign = "middle",
                color = {255, 255, 255, 160}
            }
        )

        K.register(
            0,
            560,
            360,
            180,

            function()

                Phone.locked = false

                if Sound and Sound.play then
                    Sound.play("click")
                end
            end
        )
    end
end


-- ============================================================================
-- CALL OVERLAY
-- ============================================================================

local function drawCallOverlay()

    local call = Phone.call

    if not call then
        return
    end

    K.rrect(
        0,
        0,
        360,
        740,
        0,
        {8, 10, 16, 245}
    )

    K.avatar(
        call.name,
        138,
        130,
        84
    )

    K.text(
        call.name,
        0,
        240,
        {
            w = 360,
            h = 35,
            size = 20,
            align = "center",
            valign = "middle",
            bold = true,
            color = T.text
        }
    )

    K.text(
        call.number,
        0,
        275,
        {
            w = 360,
            h = 25,
            size = 13,
            align = "center",
            valign = "middle",
            color = T.sub
        }
    )

    local status = "Calling..."

    if call.state == "RINGING" then

        status = "Incoming call..."

    elseif call.state == "ACTIVE" then

        status =
            Utils.formatDuration(
                (safeTickCount() - call.start) / 1000
            )

    elseif call.state == "ENDED" then

        status =
            call.reason or "Call ended"
    end

    K.text(
        status,
        0,
        306,
        {
            w = 360,
            h = 30,
            size = 13,
            align = "center",
            valign = "middle",
            color = T.sub
        }
    )

    if call.state == "CALLING" then

        K.btn(
            138,
            560,
            84,
            56,

            function()

                triggerServerEvent(
                    "phone:call:end",
                    localPlayer
                )
            end,

            {
                style = "danger",
                radius = 28,
                label = "Cancel"
            }
        )

    elseif call.state == "ACTIVE" then

        K.btn(
            138,
            560,
            84,
            56,

            function()

                triggerServerEvent(
                    "phone:call:end",
                    localPlayer
                )
            end,

            {
                style = "danger",
                radius = 28,
                label = "End"
            }
        )
    end
end


-- ============================================================================
-- HOME INDICATOR
-- ============================================================================

local function drawHomeIndicator()

    K.rrect(
        130,
        724,
        100,
        4,
        2,
        {255, 255, 255, 180}
    )

    K.register(
        100,
        710,
        160,
        30,

        function()

            if Phone.app ~= "home" then
                goHome()
            end
        end
    )
end


-- ============================================================================
-- APP CONTENT
-- ============================================================================

local function drawAppContent(app, dy, alpha)

    if not app or not app.render then
        return
    end

    local oldSY =
        Phone.sy

    -- dy is virtual coordinate
    Phone.sy =
        Phone.sy +
        (dy * Phone.S)

    app.render(alpha or 1)

    Phone.sy =
        oldSY
end


-- ============================================================================
-- MAIN RENDER
-- ============================================================================

function renderPhone()

    updatePhoneRect()

    local animation =
        tonumber(Phone.anim) or 1

    if animation <= 0 then
        return
    end

    local offY =
        (1 - animation) *
        (Phone.H * 1.08 + 30)

    local scale =
        0.96 +
        0.04 * animation

    local fx =
        Phone.x +
        Phone.W * (1 - scale) / 2

    local fy =
        Phone.y +
        Phone.H * (1 - scale) / 2 +
        offY

    local fw =
        Phone.W * scale

    local fh =
        Phone.H * scale

    local radius =
        fh * 0.052


    -- Shadow
    if K.rrectScreen then

        K.rrectScreen(
            fx + 8,
            fy + 15,
            fw,
            fh,
            radius,
            {0, 0, 0, 100}
        )
    end


    -- Phone frame
    if K.rrectScreen then

        K.rrectScreen(
            fx,
            fy,
            fw,
            fh,
            radius,
            T.frame
        )

        K.rrectScreen(
            fx + 2,
            fy + 2,
            fw - 4,
            fh - 4,
            radius - 2,
            {8, 9, 13, 255}
        )
    else

        dxDrawRectangle(
            fx,
            fy,
            fw,
            fh,
            C(T.frame)
        )
    end


    -- Save original geometry
    local oldSX = Phone.sx
    local oldSY = Phone.sy
    local oldSW = Phone.sw
    local oldSH = Phone.sh
    local oldS = Phone.S


    -- Animated screen geometry
    Phone.sx =
        fx + Phone.bez

    Phone.sy =
        fy + Phone.bez

    Phone.sw =
        fw - Phone.bez * 2

    Phone.sh =
        fh - Phone.bez * 2

    Phone.S =
        Phone.sh / Phone.vy


    -- =========================================================================
    -- DRAW PHONE
    -- =========================================================================

    drawWallpaper()

    drawDynamicIsland()

    Phone.updateCall()

    K.begin()

    drawStatusBar()

    if Phone.locked then

        drawLockScreen()

    else

        local app =
            Phone.appRegistry[Phone.app]
            or Phone.appRegistry.home

        if app then

            local progress = 1

            if Anim and Anim.get then
                progress =
                    Anim.get("app", 1)
            end

            local dy =
                (1 - progress) * 26

            drawAppContent(
                app,
                dy,
                progress
            )
        end

        if Phone.shade
            and Notify
            and Notify.renderShade then

            Notify.renderShade()
        end

        if Notify
            and Notify.renderToasts then

            Notify.renderToasts()
        end

        if Phone.call then
            drawCallOverlay()
        end

        drawHomeIndicator()
    end


    -- Resolve clicks
    if Input
        and Input.consumeClick then

        Input.consumeClick()
    end


    -- Restore geometry
    Phone.sx = oldSX
    Phone.sy = oldSY
    Phone.sw = oldSW
    Phone.sh = oldSH
    Phone.S = oldS
end


-- ============================================================================
-- WAYPOINT
-- ============================================================================

local mapBlip = nil

function Phone.setWaypoint(p)

    Phone.data.waypoint = p

    if mapBlip and isElement(mapBlip) then

        destroyElement(mapBlip)

        mapBlip = nil
    end

    if p then

        local x =
            tonumber(p.x) or 0

        local y =
            tonumber(p.y) or 0

        local z =
            tonumber(p.z) or 0

        mapBlip =
            createBlip(
                x,
                y,
                z,
                4
            )

        if Sound and Sound.play then
            Sound.play("click")
        end

    else

        if Sound and Sound.play then
            Sound.play("back")
        end
    end
end


-- ============================================================================
-- SCREEN SPACE ROUNDED RECT
-- ============================================================================

function K.rrectScreen(x, y, w, h, r, color, alpha)

    r = math.min(
        r,
        w / 2,
        h / 2
    )

    local col =
        C(color, alpha)

    dxDrawRectangle(
        x + r,
        y,
        w - r * 2,
        h,
        col
    )

    dxDrawRectangle(
        x,
        y + r,
        w,
        h - r * 2,
        col
    )

    dxDrawRectangle(
        x,
        y,
        r,
        r,
        col
    )

    dxDrawRectangle(
        x + w - r,
        y,
        r,
        r,
        col
    )

    dxDrawRectangle(
        x,
        y + h - r,
        r,
        r,
        col
    )

    dxDrawRectangle(
        x + w - r,
        y + h - r,
        r,
        r,
        col
    )
end