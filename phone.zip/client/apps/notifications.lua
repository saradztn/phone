-- ============================================================================
-- AURA Phone - Notification Center app
-- lists the same notifications that appear in the shade (Notify.list)
-- ============================================================================
registerPhoneApp({
    id = "notifications",
    name = "Notifications",
    render = function()
        K.rrect(0, 0, 360, 740, 0, T.screen)
        K.header("Notifications")

        local list = Notify.list
        if #list == 0 then
            K.empty("No notifications", 0, 220, 360)
            K.text("Messages, calls and alerts from your apps\nwill appear here.", 0, 300, {
                w = 360, size = 11, align = "center", color = T.faint, h = 40,
            })
        else
            K.list("notifications.app", 14, 80, 332, 740 - 80 - 18, #list, 64, function(i, y)
                local n = list[i]
                K.rrect(16, y + 3, 328, 58, 14, T.card)
                local app = Phone.appRegistry[n.icon]
                local icon = app and Phone.img[app.icon] or Phone.img["assets/icons/notifications.png"]
                if icon and dxfGetImageWidth(icon) > 0 then
                    K.icon(icon, 28, y + 13, 38)
                else
                    K.icon(Phone.img["assets/icons/notifications.png"], 28, y + 13, 38)
                end
                K.text(n.title, 78, y + 10, { size = 12.5, bold = true, w = 250, h = 20 })
                if n.msg and n.msg ~= "" then
                    K.text(n.msg, 78, y + 31, { size = 10.5, color = T.sub, w = 196, h = 24, wrap = true })
                end
                K.text(Utils.timeAgo(n.t), 288, y + 12, { w = 52, size = 9.5, align = "right", color = T.faint, h = 16 })
            end)
        end
    end,
    onClose = function()
        -- reading here clears nothing (unread counter stays) — keep it simple
    end,
})
