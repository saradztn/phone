-- ============================================================================
-- AURA Phone - Messages app
-- * conversation list (search, last message, unread badge, delete)
-- * chat view: bubbles (left/right), timestamps, read ticks, composer
-- * live append for incoming messages while the thread is open
-- ============================================================================
local st = {
    view = "list",      -- "list" | "chat"
    with = "",
    msgs = {},
    query = "",
}

local ROWH = 64
local AREA_TOP = 70
local AREA_H = 740 - 70 - 110

local function nameFor(number)
    for _, c in ipairs(Phone.data.contacts) do
        if c.number == number then return c.name end
    end
    for _, ch in ipairs(Phone.data.chats) do
        if ch.number == number and ch.name and ch.name ~= "Unknown" then return ch.name end
    end
    return number
end

local function threadList()
    if not st.query or st.query == "" then return Phone.data.chats end
    local out = {}
    for _, ch in ipairs(Phone.data.chats) do
        local hay = (ch.name .. " " .. ch.number):lower()
        if hay:find(st.query:lower(), 1, true) then table.insert(out, ch) end
    end
    return out
end

local function openChat(number)
    st.view = "chat"
    st.with = number
    st.msgs = {}
    Anim.play("app", PhoneConfig.animations.app)
    triggerServerEvent("phone:thread:fetch", number)
end

local function scrollChatToBottom(number)
    K.scrollToBottom("chat." .. number, AREA_H, #st.msgs, ROWH)
end

addEvent("phone:chats:list", true)
addEventHandler("phone:chats:list", root, function(list)
    Phone.data.chats = list or {}
end)

addEvent("phone:thread:data", true)
addEventHandler("phone:thread:data", root, function(number, msgs)
    if st.view == "chat" and st.with == number then
        st.msgs = msgs or {}
        scrollChatToBottom(number)
    end
end)

registerPhoneApp({
    id = "messages",
    name = "Messages",
    onOpen = function()
        triggerServerEvent("phone:chats:fetch")
        local pending = Phone.data.pendingChat
        if pending then
            Phone.data.pendingChat = nil
            openChat(pending)
        end
    end,
    render = function()
        K.rrect(0, 0, 360, 740, 0, T.screen)

        if st.view == "list" then
            K.header("Messages")
            K.field("messages.search", 20, 74, 320, 38, {
                placeholder = "Search conversations…", max = 24,
                edit = function(v) st.query = v end,
            })
            local list = threadList()
            if #list == 0 then
                K.empty(st.query ~= "" and "No matches" or "No conversations yet", 0, 220, 360)
            else
                K.list("messages.list", 14, 124, 332, 740 - 124 - 18, #list, 62, function(i, y)
                    local ch = list[i]
                    K.row(16, y + 3, 328, 56, function()
                        openChat(ch.number)
                    end)
                    K.avatar(ch.name or ch.number, 28, y + 11, 40)
                    K.text(ch.name or ch.number, 80, y + 9, { size = 13, bold = true, w = 200, h = 22 })
                    K.text(ch.last or "—", 80, y + 31, { size = 10.5, color = T.sub, w = 196, h = 18, wrap = true })
                    K.text(Utils.timeAgo(ch.time), 288, y + 11, { size = 9.5, color = T.faint, w = 52, align = "right", h = 16 })
                    if ch.unread and ch.unread > 0 then
                        K.badge(ch.unread, 306, y + 36)
                    end
                end)
            end
        else
            -- ------------------------- chat view
            K.header(nameFor(st.with))
            K.text(st.with, 64, 40, { size = 10, color = T.faint })
            K.register(312, 12, 34, 40, function()
                triggerServerEvent("phone:msg:del", st.with)
                st.view = "list"
            end)
            K.text("×", 312, 16, { w = 34, size = 17, align = "center", color = T.faint, h = 30 })

            -- bubbles (virtualized)
            K.list("chat." .. st.with, 12, AREA_TOP, 336, AREA_H, #st.msgs, ROWH, function(i, y)
                local m = st.msgs[i]
                local len = math.min(#m.text, 60)
                local lines = math.max(1, math.ceil(len / 30))
                lines = math.min(lines, 2)
                local shown = lines == 2 and math.min(#m.text, 60) or len
                local bw = math.min(244, 26 + shown * 6.4)
                local bh = lines * 18 + 16
                local x = m.mine and (348 - bw) or 14
                local col = m.mine and T.bubbleMe or T.bubbleThem
                K.rrect(x, y + 4, bw, bh, 12, col)
                local tcol = m.mine and { 255, 255, 255, 240 } or T.text
                K.text(m.text, x + 12, y + 4, { w = bw - 24, h = bh, size = 12, valign = "middle", color = tcol, wrap = true })
                local tick = ""
                if m.mine then
                    tick = m.read and m.read > 0 and "  ✓✓" or "  ✓"
                end
                if m.mine then
                    K.text(Utils.timeAgo(m.time) .. tick, x, y + bh + 7, { w = bw, size = 8.5, color = T.faint, align = "right", h = 12 })
                else
                    K.text(Utils.timeAgo(m.time), x, y + bh + 7, { w = bw, size = 8.5, color = T.faint, align = "left", h = 12 })
                end
            end)

            -- composer
            local cy = 740 - 84
            K.field("messages.composer", 16, cy, 282, 48, {
                placeholder = "Message", max = PhoneConfig.maxMessageLength, alnum = true,
                submit = function(v)
                    if v ~= "" then
                        triggerServerEvent("phone:msg:send", st.with, v)
                    end
                end,
            })
            K.btn(308, cy, 48, 48, function()
                if Input.focus == "messages.composer" and Input.buf ~= "" then
                    triggerServerEvent("phone:msg:send", st.with, Input.buf)
                    Input.focus = nil
                    Input.buf = ""
                end
            end, { style = "primary", radius = 24 })
            -- paper plane glyph
            local px, py = Phone.vp(325, cy + 15, 14, 14)
            dxDrawLine(px, py + 13, px + 14, py, 255, 255, 255, 235)
            dxDrawLine(px + 14, py, px + 5, py + 8, 255, 255, 255, 235)
            dxDrawLine(px + 5, py + 8, px + 10, py + 10, 255, 255, 255, 235)
            dxDrawLine(px + 10, py + 10, px, py + 13, 255, 255, 255, 235)
        end
    end,
})

-- live hooks (called by notifications.lua)
local app = Phone.appRegistry["messages"]
app.onIncoming = function(from, name, text, time)
    if st.view == "chat" and st.with == from then
        table.insert(st.msgs, { mine = false, text = text, time = time, read = 0 })
        scrollChatToBottom(from)
        Sound.play("notify")
    end
end
app.onEcho = function(number, text, time)
    if st.view == "chat" and st.with == number then
        table.insert(st.msgs, { mine = true, text = text, time = time, read = 0 })
        scrollChatToBottom(number)
        Sound.play("send")
    end
end
