-- ============================================================================
-- AURA Phone - Notes app
-- list + editor with autosave (on back / after 2.5s of idle typing)
-- ============================================================================
local st = {
    view = "list",
    editingId = nil,    -- nil = new note
    title = "",
    body = "",
    lastEdit = 0,
    dirty = false,
}

addEvent("phone:notes:list", true)
addEventHandler("phone:notes:list", root, function(list)
    Phone.data.notes = list or {}
end)

local function saveNote()
    if st.title == "" and st.body == "" then return end
    triggerServerEvent("phone:notes:save", st.editingId, st.title, st.body)
    st.dirty = false
    st.lastEdit = 0
end

registerPhoneApp({
    id = "notes",
    name = "Notes",
    onOpen = function()
        st.view = "list"
        triggerServerEvent("phone:notes:fetch")
    end,
    onClose = function()
        if st.dirty then saveNote() end
    end,
    render = function()
        K.rrect(0, 0, 360, 740, 0, T.screen)

        if st.view == "list" then
            K.header("Notes", function()
                K.btn(306, 14, 40, 36, function()
                    st.view = "edit"
                    st.editingId = nil
                    st.title, st.body, st.dirty = "", "", false
                    Sound.play("click")
                end, { style = "primary", label = "+", size = 18 })
            end)
            local notes = Phone.data.notes
            if #notes == 0 then
                K.empty("No notes yet — tap + to write one", 0, 220, 360)
            else
                K.list("notes.list", 14, 76, 332, 740 - 76 - 18, #notes, 66, function(i, y)
                    local n = notes[i]
                    K.row(16, y + 3, 328, 60, function()
                        st.view = "edit"
                        st.editingId = n.id
                        st.title = n.title
                        st.body = n.body
                        st.dirty = false
                    end)
                    K.text(n.title ~= "" and n.title or "Untitled", 30, y + 10, { size = 13, bold = true, w = 240, h = 22 })
                    local preview = n.body ~= "" and n.body:sub(1, 48) or "Empty note"
                    K.text(preview, 30, y + 33, { size = 10.5, color = T.sub, w = 250, h = 18 })
                    K.text(Utils.timeAgo(n.updated), 262, y + 12, { w = 70, size = 9.5, align = "right", color = T.faint, h = 16 })
                    K.register(262, y + 34, 70, 20, function()
                        triggerServerEvent("phone:notes:delete", n.id)
                        Sound.play("back")
                    end)
                    K.text("Delete", 262, y + 36, { w = 70, size = 9, align = "right", color = T.danger, h = 14 })
                end)
            end
        else
            -- editor
            K.header(st.editingId and "Edit note" or "New note")
            K.field("notes.title", 20, 78, 320, 40, {
                placeholder = "Title", max = PhoneConfig.maxNoteTitle, alnum = true,
                edit = function(v) st.title = v; st.dirty = true; st.lastEdit = safeTickCount() end,
            })
            K.field("notes.body", 20, 130, 320, 220, {
                placeholder = "Write something…", max = PhoneConfig.maxNoteLength, alnum = true,
                edit = function(v) st.body = v; st.dirty = true; st.lastEdit = safeTickCount() end,
            })
            -- autosave after idle typing
            if st.dirty and st.lastEdit > 0 and safeTickCount() - st.lastEdit > 2500 then
                saveNote()
            end
            local cy = 740 - 84
            K.text(#st.body .. " / " .. PhoneConfig.maxNoteLength, 20, cy + 8, { size = 10, color = T.faint })
            K.btn(250, cy, 48, 48, function()
                if st.dirty then
                    triggerServerEvent("phone:notes:save", st.editingId, st.title, st.body)
                    st.dirty = false
                end
                st.view = "list"
                Sound.play("click")
            end, { style = "primary", label = "✓", size = 18 })
        end
    end,
})
