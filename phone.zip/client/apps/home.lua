-- ============================================================================
-- AURA Phone - Home screen
-- * app grid (4 columns) + frosted dock
-- * unread badge on Messages
-- ============================================================================
local st = {}

local function isDock(id)
    for _, d in ipairs(PhoneConfig.dockApps) do
        if d == id then return true end
    end
    return false
end

local function installed(id)
    -- empty map = first session before server load: everything is on
    return next(Phone.data.installed) == nil or Phone.data.installed[id]
end

local function gridApps()
    local list = {}
    for _, app in ipairs(PhoneApps) do
        if installed(app.id) and not isDock(app.id) and app.id ~= "home" then
            table.insert(list, app)
        end
    end
    table.sort(list, function(a, b) return a.order < b.order end)
    return list
end

local function drawIcon(app, cx, cy, size, label)
    local img = Phone.img[app.icon]
    K.icon(img, cx, cy, size)
    if label ~= nil and label then
        K.text(app.name, cx - 14, cy + size + 4, { w = size + 28, size = 10, align = "center", color = { 255, 255, 255, 235 } })
    end
    if app.id == "messages" and Phone.data.unreadMsgs > 0 then
        K.badge(Phone.data.unreadMsgs, cx + size - 16, cy - 4)
    end
    K.register(cx, cy, size, size, function()
        openApp(app.id)
    end)
end

registerPhoneApp({
    id = "home",
    name = "Home",
    render = function()
        -- grid
        local apps = gridApps()
        local size = 58
        local left = 22
        local step = (360 - 44 - size) / 3
        local top = 76
        local rstep = 92
        for i, app in ipairs(apps) do
            local col = (i - 1) % 4
            local row = math.floor((i - 1) / 4)
            local cx = left + col * step
            local cy = top + row * rstep
            drawIcon(app, cx, cy, size, true)
        end

        -- dock
        local dockY = 740 - 96
        K.rrect(14, dockY, 332, 78, 26, T.dock)
        local dApps = {}
        for _, id in ipairs(PhoneConfig.dockApps) do
            local app = PhoneAppMap[id]
            if app and installed(id) then table.insert(dApps, app) end
        end
        local dSize = 54
        local dStep = (332 - 28 - dSize * #dApps) / math.max(1, #dApps - 1)
        for i, app in ipairs(dApps) do
            local cx = 28 + (i - 1) * dStep
            drawIcon(app, cx, dockY + 12, dSize, false)
        end
    end,
})
