-- ============================================================================
-- AURA Phone - Garage (vehicles) app
-- * list of linked vehicles (name, state, last position)
-- * GPS / lock / unlock / engine (validated on the server)
-- * "register current vehicle" while sitting in one
-- ============================================================================
local st = {}

addEvent("phone:vehicles:list", true)
addEventHandler("phone:vehicles:list", root, function(list)
    Phone.data.vehicles = list or {}
end)

local function inVehicle()
    local ok, v = pcall(getPedOccupiedVehicle, localPlayer, 0)
    return ok and v or nil
end

registerPhoneApp({
    id = "vehicles",
    name = "Garage",
    onOpen = function()
        triggerServerEvent("phone:vehicles:fetch")
    end,
    render = function()
        K.rrect(0, 0, 360, 740, 0, T.screen)
        K.header("Garage")

        local v = inVehicle()
        K.rrect(16, 74, 328, 56, 16, T.card)
        K.icon(Phone.img["assets/icons/vehicles.png"], 30, 86, 32)
        K.text(v and "You are in a vehicle" or "No active vehicle", 74, 84, { size = 12.5, bold = true, h = 20 })
        K.text(v and "Save it to your garage" or "Get in a car to register it", 74, 104, { size = 10, color = T.sub, h = 16 })
        K.btn(250, 84, 78, 36, function()
            triggerServerEvent("phone:vehicles:link")
        end, { style = v and "primary" or "ghost", label = v and "Add" or "—", size = 11 })

        local list = Phone.data.vehicles
        if #list == 0 then
            K.empty("No vehicles in your garage yet", 0, 200, 360)
        else
            K.list("vehicles.list", 14, 146, 332, 740 - 146 - 18, #list, 96, function(i, y)
                local car = list[i]
                K.rrect(16, y + 3, 328, 90, 14, T.card)
                K.icon(Phone.img["assets/icons/vehicles.png"], 30, y + 14, 36)
                K.text(car.name, 78, y + 12, { size = 13, bold = true, h = 22 })
                local state = car.locked and "Locked" or (car.engine and "Engine on" or "Ready")
                local sc = car.locked and T.warn or T.success
                K.rrect(78, y + 36, 54, 18, 9, sc, 140)
                K.text(state, 78, y + 36, { w = 54, size = 9, align = "center", valign = "middle", color = { 255, 255, 255, 230 }, bold = true })
                K.text("Last: " .. math.floor(car.x or 0) .. ", " .. math.floor(car.y or 0), 140, y + 36, { size = 9.5, color = T.faint, h = 16 })

                -- actions
                local by = y + 60
                K.btn(30, by, 78, 28, function()
                    Phone.setWaypoint(car)
                end, { style = "primary", label = "GPS", size = 10.5 })
                K.btn(114, by, 78, 28, function()
                    triggerServerEvent("phone:vehicles:action", car.id, car.locked and "unlock" or "lock")
                end, { style = "card", label = car.locked and "Unlock" or "Lock", size = 10.5 })
                K.btn(198, by, 78, 28, function()
                    triggerServerEvent("phone:vehicles:action", car.id, "engine")
                end, { style = "card", label = car.engine and "Engine off" or "Engine on", size = 10.5 })
            end)
        end
    end,
})
