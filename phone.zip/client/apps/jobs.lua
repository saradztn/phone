-- ============================================================================
-- AURA Phone - Jobs app
-- * current job card (set by the server via phoneSetJob)
-- * job catalog with salary + GPS to the workplace
-- ============================================================================
addEvent("phone:jobs:data", true)
addEventHandler("phone:jobs:data", root, function(data)
    Phone.data.jobs = data
end)

registerPhoneApp({
    id = "jobs",
    name = "Jobs",
    onOpen = function()
        triggerServerEvent("phone:jobs:fetch")
    end,
    render = function()
        K.rrect(0, 0, 360, 740, 0, T.screen)
        K.header("Jobs")

        local data = Phone.data.jobs
        local current = data and data.current or PhoneConfig.jobs[1]
        local isUnemp = current.id == "unemployed"

        -- current job card
        K.rrect(16, 74, 328, 96, 18, isUnemp and T.card or mixc(T.primaryDeep, { 20, 24, 40, 255 }, 0.4))
        K.icon(Phone.img["assets/icons/jobs.png"], 32, 92, 44)
        K.text("Current job", 92, 88, { size = 10.5, color = T.sub })
        K.text(current.name, 92, 108, { size = 16, bold = true })
        K.text(isUnemp and (current.desc or "") or ("Salary: $" .. Utils.formatMoney(current.salary) .. "/week"),
            92, 136, { size = 10.5, color = T.sub })

        K.text("Available positions", 24, 194, { size = 13, bold = true })

        local list = data and data.list or PhoneConfig.jobs
        if isUnemp then
            -- hide the unemployed row from the catalog
            local cat = {}
            for _, j in ipairs(list) do
                if j.id ~= "unemployed" then table.insert(cat, j) end
            end
            list = cat
        end
        if #list == 0 then
            K.empty("No openings right now", 0, 280, 360)
        else
            K.list("jobs.list", 14, 222, 332, 740 - 222 - 18, #list, 78, function(i, y)
                local j = list[i]
                K.rrect(16, y + 3, 328, 72, 14, T.card)
                K.text(j.name, 32, y + 14, { size = 13, bold = true, h = 22 })
                K.text(j.desc or "", 32, y + 36, { size = 10.5, color = T.sub, w = 210, h = 18, wrap = true })
                K.text("$" .. Utils.formatMoney(j.salary) .. "/wk", 32, y + 54, { size = 10, color = T.success, h = 16 })
                K.btn(254, y + 22, 78, 32, function()
                    Phone.setWaypoint({ name = j.name, x = j.x, y = j.y, z = j.z })
                end, { style = "primary", label = "GPS", size = 11 })
            end)
        end
    end,
})
