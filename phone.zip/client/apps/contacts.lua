-- ============================================================================
-- AURA Phone - Contacts app
-- list + search + favorites, add/edit/delete, call & message shortcuts
-- ============================================================================
local st = {
    query = "",
    detail = nil,     -- contact being viewed
    editing = nil,    -- contact being edited / "new"
    editName = "",
    editNumber = "",
}

addEvent("phone:contacts:list", true)
addEventHandler("phone:contacts:list", root, function(list)
    Phone.data.contacts = list or {}
end)

registerPhoneApp({
    id = "contacts",
    name = "Contacts",
    onOpen = function()
        triggerServerEvent("phone:contacts:fetch")
    end,
    render = function()
        K.rrect(0, 0, 360, 740, 0, T.screen)

        -- header
        K.header("Contacts", function()
            K.btn(306, 14, 40, 36, function()
                st.editing = { number = "", name = "" }
                st.editName, st.editNumber = "", ""
                Sound.play("click")
            end, { style = "primary", label = "+", size = 18 })
        end)

        -- search
        K.field("contacts.search", 20, 74, 320, 38, {
            placeholder = "Search contacts…",
            max = 24,
            alnum = true,
            edit = function(v)
                st.query = v
                triggerServerEvent("phone:contacts:search", v)
            end,
        })

        -- list
        local list = Phone.data.contacts
        if #list == 0 then
            K.empty(st.query ~= "" and "No matches" or "No contacts yet — tap + to add one", 0, 200, 360)
        else
            K.list("contacts", 14, 124, 332, 740 - 124 - 18, #list, 62, function(i, y)
                local c = list[i]
                K.row(16, y + 3, 328, 56, function()
                    st.detail = c
                end)
                K.avatar(c.name, 28, y + 11, 40)
                K.text(c.name, 80, y + 11, { size = 13, bold = true, h = 22 })
                K.text(c.number, 80, y + 31, { size = 11, color = T.sub, h = 18 })
                if c.favorite then
                    K.star(326, y + 31, 7, T.warn)
                end
            end)
        end

        -- detail modal
        if st.detail then
            local c = st.detail
            K.modal(c.name, function(vx, vy, mw, mh)
                K.avatar(c.name, vx + (mw - 72) / 2, vy + 40, 72)
                K.text(c.number, vx, vy + 122, { w = mw, size = 13, align = "center", color = T.sub })
                local by = vy + 152
                K.btn(vx + 18, by, (mw - 54) / 2, 42, function()
                    Phone.startCall(c.number, c.name)
                end, { style = "primary", label = "Call" })
                K.btn(vx + 36 + (mw - 54) / 2, by, (mw - 54) / 2, 42, function()
                    st.detail = nil
                    Phone.data.pendingChat = c.number
                    openApp("messages")
                end, { style = "card", label = "Message" })
                by = by + 52
                K.btn(vx + 18, by, (mw - 54) / 2, 42, function()
                    st.editing = { number = c.number, name = c.name }
                    st.editName, st.editNumber = c.name, c.number
                    st.detail = nil
                end, { style = "card", label = "Edit" })
                K.btn(vx + 36 + (mw - 54) / 2, by, (mw - 54) / 2, 42, function()
                    triggerServerEvent("phone:contacts:fav", c.number, not c.favorite)
                    Sound.play("click")
                end, { style = "card", label = c.favorite and "Unfavorite" or "Favorite" })
                by = by + 52
                K.btn(vx + 18, by, mw - 36, 42, function()
                    triggerServerEvent("phone:contacts:delete", c.number)
                    st.detail = nil
                end, { style = "danger", label = "Delete contact" })
            end, 340)
        end

        -- add / edit modal
        if st.editing then
            K.modal(st.editing.name ~= "" and "Edit contact" or "New contact", function(vx, vy, mw, mh)
                K.field("contacts.name", vx + 18, vy + 44, mw - 36, 40, {
                    placeholder = "Name", max = PhoneConfig.maxContactName, alnum = true,
                    edit = function(v) st.editName = v end,
                })
                K.field("contacts.number", vx + 18, vy + 94, mw - 36, 40, {
                    placeholder = "Phone number (e.g. 0551234567)", max = 12, digits = true,
                    edit = function(v) st.editNumber = v end,
                })
                local by = vy + mh - 62
                K.btn(vx + 18, by, (mw - 54) / 2, 44, function()
                    st.editing = nil
                    Sound.play("back")
                end, { style = "card", label = "Cancel" })
                K.btn(vx + 36 + (mw - 54) / 2, by, (mw - 54) / 2, 44, function()
                    if #st.editNumber >= 8 and #st.editName > 0 then
                        triggerServerEvent("phone:contacts:save", st.editNumber, st.editName)
                        st.editing = nil
                    else
                        Notify.push("contacts", "Missing data", "Enter a name and a valid number.")
                    end
                end, { style = "primary", label = "Save" })
            end)
        end
    end,
})
