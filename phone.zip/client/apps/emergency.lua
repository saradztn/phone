-- ============================================================================
-- AURA Phone - Emergency app
-- * 911 call (simulated dispatch on the server)
-- * quick dispatch: police / hospital (GPS + simulated response)
-- ============================================================================
local st = {}

registerPhoneApp({
    id = "emergency",
    name = "Emergency",
    render = function()
        K.rrect(0, 0, 360, 740, 0, T.screen)
        K.header("Emergency")

        -- 911 card
        K.rrect(16, 74, 328, 130, 18, mixc(T.dangerDeep, { 24, 10, 14, 255 }, 0.45))
        K.icon(Phone.img["assets/icons/emergency.png"], 36, 94, 44)
        K.text("911", 96, 92, { size = 26, bold = true, color = { 255, 255, 255, 255 } })
        K.text("Emergency services", 96, 128, { size = 11, color = { 255, 255, 255, 200 } })
        K.btn(238, 158, 90, 34, function()
            Phone.startCall("911", "Emergency")
        end, { style = "danger", label = "Call 911", size = 11.5 })

        -- quick dispatch
        K.text("Quick dispatch", 24, 230, { size = 13, bold = true })

        local police = PhoneConfig.poi[1]
        K.rrect(16, 258, 328, 66, 14, T.card)
        K.icon(Phone.img["assets/icons/emergency.png"], 30, 272, 38)
        K.text("Police", 82, 272, { size = 13, bold = true, h = 22 })
        K.text("Request an officer to your location", 82, 293, { size = 10, color = T.sub, h = 16 })
        K.btn(236, 272, 96, 38, function()
            triggerServerEvent("phone:emergency:call", "police")
            Phone.setWaypoint(police)
        end, { style = "danger", label = "Send unit", size = 10.5 })

        local hospital = PhoneConfig.poi[2]
        K.rrect(16, 336, 328, 66, 14, T.card)
        K.icon(Phone.img["assets/icons/emergency.png"], 30, 350, 38)
        K.text("Hospital", 82, 350, { size = 13, bold = true, h = 22 })
        K.text("Request a medic / transport", 82, 371, { size = 10, color = T.sub, h = 16 })
        K.btn(236, 350, 96, 38, function()
            triggerServerEvent("phone:emergency:call", "hospital")
            Phone.setWaypoint(hospital)
        end, { style = "danger", label = "Send unit", size = 10.5 })

        K.rrect(16, 430, 328, 120, 14, T.card)
        K.text("In an emergency", 32, 446, { size = 12.5, bold = true })
        K.text("1. Stay calm and give your location.\n2. Note nearby landmarks.\n3. Do not hang up until told to.\n4. Keep the phone on loudspeaker.",
            32, 470, { size = 10.5, color = T.sub, w = 296, h = 70, wrap = true })

        K.text("For roleplay use only — this is a fictional service.", 0, 690, { w = 360, size = 9, align = "center", color = T.faint })
    end,
})
