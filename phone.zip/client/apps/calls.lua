-- ============================================================================
-- AURA Phone - Phone (calls) app
-- * keypad dialer with live number entry
-- * recents list (missed / incoming / outgoing, duration, re-call)
-- * client-side state handlers for the call overlay (Phone.call)
-- ============================================================================
local st = {
    tab = "dial",   -- "dial" | "recents"
    num = "",
}

local function nameFor(number)
    for _, c in ipairs(Phone.data.contacts) do
        if c.number == number then return c.name end
    end
    return number
end

local KEYS = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#" }

-- ---------------------------------------------------------------------------
-- call state events (drive the overlay in ui.lua)
-- ---------------------------------------------------------------------------
addEvent("phone:call:incoming", true)
addEventHandler("phone:call:incoming", root, function(number, name)
    if Phone.call then
        -- line busy: decline
        triggerServerEvent("phone:call:decline")
        return
    end
    local id = Sound.play("ring")
    Phone.call = { number = number, name = name or number, state = "RINGING", start = safeTickCount(), soundId = id }
end)

addEvent("phone:call:state", true)
addEventHandler("phone:call:state", root, function(state, number, name, duration, reason)
    local c = Phone.call
    if state == "CALLING" then
        if not c then
            Phone.call = { number = number, name = name or number, state = "CALLING", start = safeTickCount() }
        end
    elseif state == "ACTIVE" then
        if c then
            c.state = "ACTIVE"
            c.start = safeTickCount()
            c.reason = nil
            if c.soundId then stopClientSound(c.soundId) c.soundId = nil end
        end
    elseif state == "ENDED" then
        if c then
            c.state = "ENDED"
            c.duration = duration
            c.reason = reason
            c.number = number or c.number
            c.name = name or c.name
            if c.soundId then stopClientSound(c.soundId) c.soundId = nil end
        else
            -- e.g. missed while the phone was closed: count it
            if reason == "Missed call" then Phone.data.unreadCalls = Phone.data.unreadCalls + 1 end
        end
    end
end)

-- voice bridge hooks (no-op unless a voice system exists on the server)
addEvent("phone:voice:start", true)
addEventHandler("phone:voice:start", root, function(channel)
    -- example integration point: open a voice channel named `channel`
    outputDebugString("[phone] voice channel: " .. tostring(channel))
end)
addEvent("phone:voice:stop", true)
addEventHandler("phone:voice:stop", root, function()
    outputDebugString("[phone] voice channel closed")
end)

addEvent("phone:calllog:data", true)
addEventHandler("phone:calllog:data", root, function(list)
    Phone.data.calllog = list or {}
end)

-- ---------------------------------------------------------------------------
registerPhoneApp({
    id = "calls",
    name = "Phone",
    onOpen = function()
        triggerServerEvent("phone:calllog:fetch")
    end,
    render = function()
        K.rrect(0, 0, 360, 740, 0, T.screen)
        K.header("Phone")

        -- tabs
        local tabs = { { id = "dial", label = "Keypad" }, { id = "recents", label = "Recents" } }
        for i, tb in ipairs(tabs) do
            local on = st.tab == tb.id
            K.btn(20 + (i - 1) * 116, 74, 108, 34, function()
                st.tab = tb.id
                Anim.play("app", 160)
            end, { style = on and "primary" or "ghost", label = tb.label, size = 12 })
        end

        if st.tab == "dial" then
            -- number display
            K.text(st.num ~= "" and st.num or "Enter a number", 0, 140, {
                w = 360, size = 26, align = "center", bold = true,
                color = st.num ~= "" and T.text or T.faint,
            })
            if st.num ~= "" then
                K.text(nameFor(st.num), 0, 176, { w = 360, size = 11, align = "center", color = T.sub })
            end

            -- keypad
            for i, key in ipairs(KEYS) do
                local col = (i - 1) % 3
                local row = math.floor((i - 1) / 3)
                local kx, ky = 96 + col * 58, 240 + row * 62
                K.btn(kx, ky, 50, 52, function()
                    st.num = st.num .. key
                    Sound.play("click")
                end, { style = "ghost", label = key, size = 18, radius = 25 })
            end

            -- bottom row: delete / call / clear
            K.btn(96, 500, 50, 52, function()
                if st.num ~= "" then
                    st.num = st.num:sub(1, -2)
                    Sound.play("back")
                end
            end, { style = "ghost", label = "⌫", size = 18, radius = 25 })
            K.btn(154, 500, 50, 52, function()
                if #st.num >= 8 then
                    local n = st.num
                    local nm = n == "911" and "Emergency" or nameFor(n)
                    st.num = ""
                    Phone.startCall(n, nm)
                else
                    Notify.push("calls", "Invalid number", "At least 8 digits.")
                end
            end, { style = "success", radius = 26 })
            K.icon(Phone.img["assets/icons/calls.png"], 169, 515, 20)
            K.btn(212, 500, 50, 52, function()
                st.num = ""
                Sound.play("back")
            end, { style = "ghost", label = "C", size = 14, radius = 25 })

            K.text(Phone.data.number, 0, 700, { w = 360, size = 9.5, align = "center", color = T.faint })
        else
            -- recents
            local log = Phone.data.calllog
            if #log == 0 then
                K.empty("No recent calls", 0, 240, 360)
            else
                K.list("calls.recents", 14, 124, 332, 740 - 124 - 18, #log, 62, function(i, y)
                    local c = log[i]
                    K.row(16, y + 3, 328, 56, function()
                        st.num = c.number
                        st.tab = "dial"
                    end)
                    -- direction icon
                    local ix, iy = Phone.vp(30, y + 14, 22, 22)
                    if c.status == "MISSED" then
                        K.text("!", ix, iy, { w = 22, size = 15, align = "center", valign = "middle", color = T.danger, bold = true })
                    elseif c.mine then
                        K.text("↗", ix, iy, { w = 22, size = 14, align = "center", valign = "middle", color = T.sub })
                    else
                        K.text("↙", ix, iy, { w = 22, size = 14, align = "center", valign = "middle", color = T.sub })
                    end
                    K.text(c.name or c.number, 64, y + 10, { size = 13, bold = true, w = 200, h = 22 })
                    local sub
                    if c.status == "MISSED" then
                        sub = "Missed"
                    elseif c.status == "REJECTED" then
                        sub = c.mine and "Declined" or "Declined"
                    elseif c.status == "BUSY" then
                        sub = "Busy"
                    else
                        sub = Utils.formatDuration(c.duration)
                    end
                    K.text(Utils.timeAgo(c.time) .. " • " .. sub, 64, y + 31, { size = 10.5, color = c.status == "MISSED" and T.danger or T.sub, h = 18 })
                end)
            end
        end
    end,
})
