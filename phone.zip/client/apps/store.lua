-- ============================================================================
-- AURA Phone - App Store
-- * catalog from shared/apps.lua + coming-soon items
-- * install / remove (persisted per player on the server)
-- ============================================================================
local st = {}

addEvent("phone:store:list", true)
addEventHandler("phone:store:list", root, function(list)
    Phone.data.store = list or {}
end)

addEvent("phone:store:state", true)
addEventHandler("phone:store:state", root, function(appId, installed)
    Phone.data.installed[appId] = installed == 1
    for _, s in ipairs(Phone.data.store) do
        if s.id == appId then s.installed = installed == 1 end
    end
end)

registerPhoneApp({
    id = "store",
    name = "App Store",
    onOpen = function()
        triggerServerEvent("phone:store:fetch")
    end,
    render = function()
        K.rrect(0, 0, 360, 740, 0, T.screen)
        K.header("App Store")

        K.rrect(16, 74, 328, 84, 18, mixc(T.info, { 18, 22, 36, 255 }, 0.3))
        K.icon(Phone.img["assets/icons/store.png"], 32, 92, 48)
        K.text("AURA App Store", 94, 90, { size = 15, bold = true })
        K.text("All apps are free on AURA Mobile", 94, 116, { size = 10.5, color = T.sub })

        local list = Phone.data.store
        if #list == 0 then
            K.spinner(160, 300, 40)
        else
            K.list("store.list", 14, 174, 332, 740 - 174 - 18, #list, 86, function(i, y)
                local s = list[i]
                K.rrect(16, y + 3, 328, 80, 14, T.card)
                local app = PhoneAppMap[s.id]
                K.icon(app and Phone.img[app.icon] or Phone.img["assets/icons/settings.png"], 30, y + 16, 52)
                K.text(s.name, 96, y + 14, { size = 13, bold = true, h = 22 })
                K.text(s.desc or "", 96, y + 36, { size = 10, color = T.sub, w = 170, h = 30, wrap = true })
                if s.soon then
                    K.rrect(272, y + 26, 58, 28, 14, { 80, 88, 108, 120 })
                    K.text("Soon", 272, y + 26, { w = 58, size = 10.5, align = "center", valign = "middle", color = { 255, 255, 255, 160 }, bold = true })
                elseif s.installed then
                    K.btn(262, y + 22, 68, 36, function()
                        openApp(s.id)
                    end, { style = "ghost", label = "Open", size = 11 })
                    K.register(262, y + 58, 68, 18, function()
                        triggerServerEvent("phone:store:toggle", s.id)
                    end)
                    K.text("Remove", 262, y + 58, { w = 68, size = 9, align = "center", color = T.danger, h = 14 })
                else
                    K.btn(262, y + 22, 68, 36, function()
                        triggerServerEvent("phone:store:toggle", s.id)
                    end, { style = "primary", label = "Get", size = 11 })
                end
            end)
        end
    end,
})
