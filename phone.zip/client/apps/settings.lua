-- ============================================================================
-- AURA Phone - Settings app
-- * Appearance: dark/light theme, wallpaper, UI scale
-- * Sound: ring / notification / sfx levels (0 mutes — MTA has no
--   per-sound volume API, so levels act as mute thresholds)
-- * Phone: device name (server), PIN lock (server)
-- * Notifications: per-category toggles (client)
-- * About
-- ============================================================================
local st = {
    section = "main",   -- "main" | "wallpaper" | "pin"
    phoneName = "",
    pinValue = "",
}

local function row(vy, icon, label, sub, rightFn)
    K.rrect(16, vy, 328, 58, 14, T.card)
    K.icon(Phone.img[icon] or Phone.img["assets/icons/settings.png"], 28, vy + 12, 34)
    K.text(label, 74, vy + 9, { size = 12.5, bold = true, h = 22 })
    if sub then
        K.text(sub, 74, vy + 30, { size = 10, color = T.sub, h = 18 })
    end
    if rightFn then rightFn(vy) end
end

registerPhoneApp({
    id = "settings",
    name = "Settings",
    onOpen = function()
        st.section = "main"
        st.phoneName = Phone.settings.phoneName
        st.pinValue = Phone.settings.pin
    end,
    render = function()
        K.rrect(0, 0, 360, 740, 0, T.screen)

        if st.section == "wallpaper" then
            K.header("Wallpaper")
            local opts = { 0 }
            for i = 1, #PhoneConfig.wallpapers do table.insert(opts, i) end
            local y = 84
            for _, idx in ipairs(opts) do
                K.rrect(16, y, 328, 96, 14, T.card)
                if idx == 0 then
                    K.rrect(30, y + 12, 72, 72, 12, { 20, 30, 58, 255 })
                else
                    local img = Phone.img["wp" .. idx]
                    if img and dxfGetImageWidth(img) > 0 then
                        K.icon(img, 30, y + 12, 72)
                    else
                        K.rrect(30, y + 12, 72, 72, 12, T.cardSoft)
                    end
                end
                K.text(idx == 0 and "Classic" or ("Wallpaper " .. idx), 114, y + 24, { size = 13, bold = true, h = 22 })
                local on = Phone.settings.wallpaper == idx
                K.rrect(296, y + 28, 30, 30, 15, on and T.primary or { 80, 88, 108, 255 })
                if on then
                    K.text("✓", 296, y + 28, { w = 30, size = 14, align = "center", valign = "middle", color = { 12, 24, 18, 255 }, bold = true })
                end
                K.register(16, y, 328, 96, function()
                    Phone.settings.wallpaper = idx
                    Sound.play("click")
                end)
                y = y + 106
            end
            return
        end

        K.header("Settings")

        -- Appearance
        K.text("APPEARANCE", 24, 76, { size = 10, color = T.faint, bold = true })
        row(100, "assets/icons/settings.png", "Dark mode", "Interface theme", function(vy)
            K.toggle(282, vy + 17, 48, 24, Phone.settings.theme == "dark", function(on)
                Phone.settings.theme = on and "dark" or "light"
                Theme.apply(Phone.settings.theme)
            end)
        end)
        row(166, "assets/icons/gallery.png", "Wallpaper", "Choose your background", function(vy)
            K.text("›", 322, vy + 8, { size = 16, color = T.faint, h = 40, valign = "middle" })
            K.register(200, vy, 144, 58, function()
                st.section = "wallpaper"
                Sound.play("click")
            end)
        end)
        K.rrect(16, 232, 328, 58, 14, T.card)
        K.text("UI scale", 32, 241, { size = 12.5, bold = true, h = 20 })
        K.slider("settings.scale", 32, 262, 240, (Phone.settings.uiScale - 0.85) / 0.3 * 100, { min = 0, max = 100, step = 5 }, function(v)
            Phone.settings.uiScale = 0.85 + (v / 100) * 0.3
        end)
        K.text(math.floor((Phone.settings.uiScale) * 100) .. "%", 284, 241, { size = 11, color = T.sub, w = 50, align = "right", h = 20 })

        -- Sound
        K.text("SOUND", 24, 312, { size = 10, color = T.faint, bold = true })
        local snd = {
            { label = "Ringtone", key = "ringVol" },
            { label = "Notifications", key = "notifyVol" },
            { label = "Sounds", key = "sfxVol" },
        }
        for i, s in ipairs(snd) do
            local vy = 336 + (i - 1) * 58
            K.rrect(16, vy, 328, 58, 14, T.card)
            K.text(s.label, 32, vy + 9, { size = 12.5, bold = true, h = 20 })
            K.slider("settings." .. s.key, 32, vy + 30, 240, Phone.settings[s.key], { min = 0, max = 100, step = 5 }, function(v)
                Phone.settings[s.key] = v
                if v == 0 then Sound.play("click") end
            end)
            K.text(Phone.settings[s.key] .. "%", 284, vy + 9, { size = 11, color = T.sub, w = 50, align = "right", h = 20 })
        end

        -- Phone
        K.text("PHONE", 24, 518, { size = 10, color = T.faint, bold = true })
        row(542, "assets/icons/calls.png", "Phone name", Phone.settings.phoneName, function(vy)
            K.field("settings.name", 130, vy + 12, 130, 34, {
                placeholder = "Device name", max = 16, alnum = true,
                edit = function(v) st.phoneName = v end,
                submit = function(v)
                    if v ~= "" then triggerServerEvent("phone:settings:set", "phoneName", v) end
                end,
            })
        end)
        row(608, "assets/icons/notifications.png", "PIN lock", Phone.settings.pinEnabled and ("PIN " .. (Phone.settings.pin ~= "" and "••••" or "not set")) or "Off", function(vy)
            K.toggle(282, vy + 17, 48, 24, Phone.settings.pinEnabled, function(on)
                Phone.settings.pinEnabled = on
                triggerServerEvent("phone:settings:set", "pinEnabled", on and 1 or 0)
            end)
        end)
        if Phone.settings.pinEnabled then
            K.field("settings.pin", 20, 676, 200, 40, {
                placeholder = "New PIN (4 digits)", max = 4, digits = true,
                edit = function(v) st.pinValue = v end,
                submit = function(v)
                    if #v == 4 then
                        triggerServerEvent("phone:settings:set", "pin", v)
                    else
                        Notify.push("settings", "Invalid PIN", "Use exactly 4 digits.")
                    end
                end,
            })
        end

        -- About
        K.rrect(232, 676, 112, 40, 12, T.card)
        K.text("About", 232, 676, { w = 112, size = 11.5, align = "center", valign = "middle", color = T.sub, bold = true })
        K.register(232, 676, 112, 40, function()
            Notify.push("settings", PhoneConfig.appName, "AURA Phone v1.0 • " .. PhoneConfig.carrier)
        end)
    end,
})

addEvent("phone:settings:saved", true)
addEventHandler("phone:settings:saved", root, function(key, value)
    if key == "phoneName" then Phone.settings.phoneName = tostring(value)
    elseif key == "pin" then Phone.settings.pin = tostring(value)
    elseif key == "pinEnabled" then Phone.settings.pinEnabled = (value == "1" or value == 1) end
end)
