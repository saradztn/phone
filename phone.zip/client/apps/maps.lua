-- ============================================================================
-- AURA Phone - Maps app
-- * city POIs (config) with live distance from the player
-- * search, waypoint set/clear (minimap blip)
-- ============================================================================
local st = { query = "" }

local function pois()
    if not st.query or st.query == "" then return PhoneConfig.poi end
    local out = {}
    for _, p in ipairs(PhoneConfig.poi) do
        if p.name:lower():find(st.query:lower(), 1, true) then table.insert(out, p) end
    end
    return out
end

local function distance(p)
    local ok, x, y, z = pcall(getElementPosition, localPlayer)
    if not ok then return nil end
    local d = getDistanceBetweenPoints3D(x, y, z, p.x, p.y, p.z)
    if d < 1000 then return string.format("%.1f km", d / 1000) end
    return string.format("%.0f km", d / 1000)
end

registerPhoneApp({
    id = "maps",
    name = "Maps",
    render = function()
        K.rrect(0, 0, 360, 740, 0, T.screen)
        K.header("Maps")

        -- current waypoint card
        local wp = Phone.data.waypoint
        K.rrect(16, 74, 328, 56, 16, T.card)
        K.text(wp and wp.name or "No active waypoint", 32, 84, { size = 12.5, bold = true, h = 22 })
        if wp then
            K.text("(" .. math.floor(wp.x) .. ", " .. math.floor(wp.y) .. ")", 32, 106, { size = 10, color = T.sub })
            K.btn(262, 84, 68, 36, function()
                Phone.setWaypoint(nil)
            end, { style = "danger", label = "Clear", size = 11 })
        else
            K.text("Tap a location to set GPS", 32, 106, { size = 10, color = T.faint })
        end

        K.field("maps.search", 20, 146, 320, 38, {
            placeholder = "Search locations…", max = 24,
            edit = function(v) st.query = v end,
        })

        local list = pois()
        if #list == 0 then
            K.empty("No locations found", 0, 260, 360)
        else
            K.list("maps.list", 14, 198, 332, 740 - 198 - 18, #list, 62, function(i, y)
                local p = list[i]
                K.row(16, y + 3, 328, 56, function()
                    Phone.setWaypoint(p)
                end)
                K.icon(Phone.img["assets/icons/maps.png"], 30, y + 13, 36)
                K.text(p.name, 80, y + 11, { size = 13, bold = true, h = 22 })
                local dist = distance(p)
                K.text(dist and dist or "—", 80, y + 32, { size = 10.5, color = T.sub, h = 18 })
                K.text("GPS ›", 286, y + 14, { w = 48, size = 10.5, align = "right", valign = "middle", color = T.primary, h = 32, bold = true })
            end)
        end
    end,
})
