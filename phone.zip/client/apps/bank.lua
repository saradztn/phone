-- ============================================================================
-- AURA Phone - Bank app
-- balance card, transfer flow, transaction history
-- ============================================================================
local st = {
    transferring = false,
    to = "",
    amount = "",
}

addEvent("phone:bank:data", true)
addEventHandler("phone:bank:data", root, function(balance, txns)
    Phone.data.bank.balance = tonumber(balance) or 0
    if txns then Phone.data.bank.txns = txns end
end)

registerPhoneApp({
    id = "bank",
    name = "Bank",
    onOpen = function()
        triggerServerEvent("phone:bank:fetch")
    end,
    render = function()
        K.rrect(0, 0, 360, 740, 0, T.screen)
        K.header("Bank")

        -- balance card
        K.rrect(16, 74, 328, 110, 18, mixc(T.primaryDeep, { 20, 24, 40, 255 }, 0.35))
        K.text("Available balance", 36, 90, { size = 11, color = { 255, 255, 255, 200 } })
        K.text("$" .. Utils.formatMoney(Phone.data.bank.balance), 36, 112, { size = 30, bold = true, color = { 255, 255, 255, 255 } })
        K.text(Phone.data.number, 36, 160, { size = 10, color = { 255, 255, 255, 160 } })
        K.btn(238, 96, 90, 36, function()
            st.transferring = true
            st.to, st.amount = "", ""
            Sound.play("click")
        end, { style = "primary", label = "Transfer", size = 12 })

        -- history
        K.text("Recent activity", 24, 206, { size = 13, bold = true })
        local txns = Phone.data.bank.txns or {}
        if #txns == 0 then
            K.empty("No transactions yet", 0, 280, 360)
        else
            K.list("bank.txns", 14, 234, 332, 740 - 234 - 18, #txns, 56, function(i, y)
                local t = txns[i]
                K.rrect(16, y + 2, 328, 52, 14, T.card)
                local col = t.out and T.danger or T.success
                K.rrect(28, y + 11, 34, 34, 17, col, 220)
                K.text(t.out and "↑" or "↓", 28, y + 11, { w = 34, size = 15, align = "center", valign = "middle", color = { 255, 255, 255, 240 }, bold = true })
                K.text((t.out and "To " or "From ") .. (t.name or t.number), 74, y + 10, { size = 12, bold = true, w = 180, h = 20 })
                K.text(Utils.timeAgo(t.time), 74, y + 30, { size = 10, color = T.sub, h = 16 })
                K.text((t.out and "-$" or "+$") .. Utils.formatMoney(t.amount), 262, y + 12, {
                    w = 70, size = 12.5, align = "right", valign = "middle", h = 32,
                    color = col, bold = true,
                })
            end)
        end

        -- transfer modal
        if st.transferring then
            K.modal("Transfer funds", function(vx, vy, mw, mh)
                K.field("bank.to", vx + 18, vy + 42, mw - 36, 40, {
                    placeholder = "Recipient number", max = 12, digits = true,
                    edit = function(v) st.to = v end,
                })
                K.field("bank.amount", vx + 18, vy + 92, mw - 36, 40, {
                    placeholder = "Amount", max = 9, digits = true,
                    edit = function(v) st.amount = v end,
                })
                K.text("Balance: $" .. Utils.formatMoney(Phone.data.bank.balance), vx + 18, vy + 140, { size = 10.5, color = T.sub })
                local by = vy + mh - 62
                K.btn(vx + 18, by, (mw - 54) / 2, 44, function()
                    st.transferring = false
                    Sound.play("back")
                end, { style = "card", label = "Cancel" })
                K.btn(vx + 36 + (mw - 54) / 2, by, (mw - 54) / 2, 44, function()
                    local amt = tonumber(st.amount)
                    if #st.to >= 8 and amt and amt > 0 then
                        triggerServerEvent("phone:bank:transfer", st.to, amt)
                        st.transferring = false
                    else
                        Notify.push("bank", "Invalid", "Enter a valid number and amount.")
                    end
                end, { style = "primary", label = "Send" })
            end)
        end
    end,
})
