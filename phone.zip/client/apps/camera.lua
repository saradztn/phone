-- ============================================================================
-- AURA Phone - Camera app (+ Photos/gallery)
-- * viewfinder with corner frame, shutter, flip
-- * captures with screenShotToFile (MTA 1.5.9.4604+); saved under
--   <client>/screenshots/phone/ and listed in the gallery with listFiles
-- ============================================================================
local st = {
    view = "finder",  -- "finder" | "gallery"
    mirror = false,
    photos = {},
    last = nil,
}

local PHOTO_DIR = "screenshots/phone"

local function refreshGallery()
    local ok, files = pcall(listFiles, "*.png", PHOTO_DIR)
    local list = {}
    if ok and type(files) == "table" then
        for _, f in ipairs(files) do
            table.insert(list, f)
        end
    end
    table.sort(list, function(a, b) return a > b end)
    st.photos = list
    Phone.data.photos = list
    st.last = list[1]
end

addEvent("phone:gallery:open", true)
addEventHandler("phone:gallery:open", root, function()
    st.view = "gallery"
    refreshGallery()
end)

registerPhoneApp({
    id = "camera",
    name = "Camera",
    onOpen = function()
        Phone.data.camView = "finder"
    end,
    render = function()
        st.view = Phone.data.camView or "finder"
        K.rrect(0, 0, 360, 740, 0, { 8, 10, 14, 255 })
        K.header(st.view == "finder" and "Camera" or "Photos")

        if st.view == "finder" then
            -- viewfinder frame (stylized live view)
            K.rrect(20, 84, 320, 380, 16, { 16, 20, 30, 255 })
            -- subtle diagonal gradient to suggest a scene
            for i = 0, 8 do
                K.rrect(20, 84 + i * 48, 320, 48, 0, { 26 + i * 3, 32 + i * 4, 48 + i * 5, 60 })
            end
            K.rrect(20, 84, 320, 380, 16, { 0, 0, 0, 0 })
            -- corner frame
            local c1x, c1y = Phone.vp(36, 100, 22, 3)
            dxDrawRectangle(c1x, c1y, 22 * Phone.S, 3 * Phone.S, C(T.primary))
            local c2x, c2y = Phone.vp(36, 100, 3, 22)
            dxDrawRectangle(c2x, c2y, 3 * Phone.S, 22 * Phone.S, C(T.primary))
            local c3x, c3y = Phone.vp(302, 451, 22, 3)
            dxDrawRectangle(c3x, c3y, 22 * Phone.S, 3 * Phone.S, C(T.primary))
            local c4x, c4y = Phone.vp(321, 432, 3, 22)
            dxDrawRectangle(c4x, c4y, 3 * Phone.S, 22 * Phone.S, C(T.primary))
            -- center crosshair
            local mx, my = Phone.vp(176, 270, 8, 1.6)
            dxDrawRectangle(mx, my, 8 * Phone.S, 1.6 * Phone.S, C({ 255, 255, 255, 200 }))
            local mx2, my2 = Phone.vp(179.2, 267, 1.6, 8)
            dxDrawRectangle(mx2, my2, 1.6 * Phone.S, 8 * Phone.S, C({ 255, 255, 255, 200 }))
            if st.mirror then
                K.text("MIRROR", 32, 434, { size = 9, color = T.faint })
            end

            -- bottom bar: gallery thumb / shutter / flip
            if st.last then
                local img = Phone.img[st.last]
                if img and dxfGetImageWidth(img) > 0 then
                    K.icon(img, 46, 520, 44)
                else
                    K.rrect(46, 520, 44, 44, 8, T.cardSoft)
                    K.icon(Phone.img["assets/icons/gallery.png"], 54, 528, 28)
                end
                K.register(46, 520, 44, 44, function()
                    Phone.data.camView = "gallery"
                    refreshGallery()
                    Sound.play("click")
                end)
            end

            K.btn(154, 512, 64, 64, function()
                Sound.play("send")
                if screenShotToFile then
                    local fname = PHOTO_DIR .. "/" .. os.time() .. "_" .. (safeTickCount() % 10000) .. ".png"
                    local ok2 = pcall(screenShotToFile, fname)
                    if ok2 then
                        Notify.push("camera", "Photo saved", "Check your photo album.")
                        refreshGallery()
                    else
                        Notify.push("camera", "Capture failed", "")
                    end
                else
                    Notify.push("camera", "Not available", "Screenshot capture needs a newer MTA client.")
                end
            end, { style = "card", radius = 32 })
            -- white shutter circle
            K.rrect(162, 520, 48, 48, 24, { 255, 255, 255, 240 })

            K.btn(270, 520, 44, 44, function()
                st.mirror = not st.mirror
                Sound.play("click")
            end, { style = "ghost", radius = 22, label = "⇄", size = 16 })

            K.text("Tip: the camera captures the game screen", 0, 620, { w = 360, size = 10, align = "center", color = T.faint })
        else
            -- gallery grid
            if #st.photos == 0 then
                K.empty("No photos yet — take one from the camera", 0, 260, 360)
                K.btn(120, 340, 120, 40, function()
                    Phone.data.camView = "finder"
                end, { style = "primary", label = "Open camera" })
            else
                local size = 100
                local gap = 10
                local left = (360 - (3 * size + 2 * gap)) / 2
                K.list("camera.gallery", 14, 84, 332, 740 - 84 - 18, math.ceil(#st.photos / 3), 112, function(i, y)
                    local idx = (i - 1) * 3
                    for j = 0, 2 do
                        local f = st.photos[idx + j + 1]
                        if f then
                            local x = left + j * (size + gap)
                            local img = Phone.img[f]
                            if not img then
                                img = dxfCreateImage(f)
                                Phone.img[f] = img
                            end
                            if img and dxfGetImageWidth(img) > 0 then
                                K.rrect(x, y + 4, size, size, 10, { 40, 44, 56, 255 })
                                K.icon(img, x + 3, y + 7, size - 6)
                            else
                                K.rrect(x, y + 4, size, size, 10, T.cardSoft)
                                K.icon(Phone.img["assets/icons/camera.png"], x + (size - 40) / 2, y + (size - 40) / 2, 40)
                            end
                        end
                    end
                end)
            end
        end
    end,
})

-- the Photos app on the home screen opens the gallery directly
local camApp = Phone.appRegistry["camera"]
registerPhoneApp({
    id = "gallery",
    name = "Photos",
    onOpen = function()
        Phone.data.camView = "gallery"
        refreshGallery()
    end,
    render = function()
        Phone.data.camView = "gallery"
        camApp.render()
    end,
})
