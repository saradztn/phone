-- ============================================================================
-- AURA Phone - Homes (properties) app
-- * list of real estate (name, type, location)
-- * GPS + info modal
-- Properties are registered by your houses resource via phoneAddProperty()
-- ============================================================================
local st = { detail = nil }

addEvent("phone:properties:list", true)
addEventHandler("phone:properties:list", root, function(list)
    Phone.data.properties = list or {}
end)

registerPhoneApp({
    id = "properties",
    name = "Homes",
    onOpen = function()
        triggerServerEvent("phone:properties:fetch")
    end,
    render = function()
        K.rrect(0, 0, 360, 740, 0, T.screen)
        K.header("Homes")

        local list = Phone.data.properties
        if #list == 0 then
            K.empty("No properties yet. Buy a home to see it here.", 0, 220, 360)
        else
            K.list("properties.list", 14, 84, 332, 740 - 84 - 18, #list, 76, function(i, y)
                local p = list[i]
                K.row(16, y + 3, 328, 70, function()
                    st.detail = p
                end)
                K.icon(Phone.img["assets/icons/properties.png"], 30, y + 16, 40)
                K.text(p.name, 84, y + 14, { size = 13, bold = true, h = 22 })
                K.text(p.type or "House", 84, y + 36, { size = 10.5, color = T.sub, h = 18 })
                K.text("›", 322, y + 12, { size = 16, color = T.faint, h = 44, valign = "middle" })
            end)
        end

        if st.detail then
            local p = st.detail
            K.modal(p.name, function(vx, vy, mw, mh)
                K.icon(Phone.img["assets/icons/properties.png"], vx + (mw - 56) / 2, vy + 30, 56)
                K.text(p.type or "House", vx, vy + 98, { w = mw, size = 12, align = "center", color = T.sub })
                K.text("Location: " .. math.floor(p.x or 0) .. ", " .. math.floor(p.y or 0) .. ", " .. math.floor(p.z or 0),
                    vx, vy + 122, { w = mw, size = 11, align = "center", color = T.faint })
                local by = vy + mh - 62
                K.btn(vx + 18, by, (mw - 54) / 2, 44, function()
                    st.detail = nil
                    Sound.play("back")
                end, { style = "card", label = "Close" })
                K.btn(vx + 36 + (mw - 54) / 2, by, (mw - 54) / 2, 44, function()
                    Phone.setWaypoint(p)
                    st.detail = nil
                end, { style = "primary", label = "Set GPS" })
            end)
        end
    end,
})
