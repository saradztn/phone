-- ============================================================================
-- AURA Phone - Server app (weather + server info)
-- * server name, players online, MTA version, weather line
-- * your identity card (name + phone number)
-- ============================================================================
addEvent("phone:serverinfo", true)
addEventHandler("phone:serverinfo", root, function(info)
    Phone.data.serverInfo = info
end)

registerPhoneApp({
    id = "weather",
    name = "Server",
    onOpen = function()
        triggerServerEvent("phone:server:info")
    end,
    render = function()
        K.rrect(0, 0, 360, 740, 0, T.screen)
        K.header("Server")

        local info = Phone.data.serverInfo or {}
        local t = getRealTime()

        -- weather card
        K.rrect(16, 74, 328, 110, 18, mixc(T.info, { 18, 24, 40, 255 }, 0.25))
        K.icon(Phone.img["assets/icons/weather.png"], 32, 92, 48)
        K.text(info.weather or PhoneConfig.weather, 94, 92, { size = 17, bold = true })
        K.text(Utils.formatDateLong(t), 94, 122, { size = 11, color = T.sub })
        K.text(Utils.formatClock(t), 250, 92, { size = 22, bold = true, color = { 255, 255, 255, 235 } })

        -- stats rows
        local rows = {
            { "Server", info.name or "—" },
            { "Players online", tostring(info.players or "…") },
            { "MTA version", info.version or "…" },
            { "Your ping", getRealPing() .. " ms" },
        }
        local y = 206
        for _, r in ipairs(rows) do
            K.rrect(16, y, 328, 46, 12, T.card)
            K.text(r[1], 32, y + 8, { size = 11, color = T.sub, h = 18 })
            K.text(r[2], 32, y + 24, { size = 12.5, bold = true, h = 18 })
            y = y + 54
        end

        -- identity card
        K.rrect(16, y + 8, 328, 96, 16, T.card)
        K.avatar(Phone.playerName ~= "" and Phone.playerName or "You", 32, y + 26, 60)
        K.text(Phone.playerName ~= "" and Phone.playerName or "Player", 106, y + 26, { size = 14, bold = true, h = 24 })
        K.text("Phone: " .. (Phone.data.number or "assigning…"), 106, y + 54, { size = 11.5, color = T.sub, h = 20 })
        K.text(PhoneConfig.carrier, 106, y + 76, { size = 10, color = T.faint, h = 16 })

        K.text(PhoneConfig.appName .. " • " .. PhoneConfig.carrier, 0, 706, { w = 360, size = 9, align = "center", color = T.faint })
    end,
})
