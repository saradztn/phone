-- ============================================================================
-- AURA Phone - Shared Utilities
-- ============================================================================

Utils = Utils or {}


-- ============================================================================
-- Clamp
-- ============================================================================

function Utils.clamp(v, a, b)

    v = tonumber(v) or 0
    a = tonumber(a) or 0
    b = tonumber(b) or 0

    -- حماية إذا تم عكس الحدود
    if a > b then
        a, b = b, a
    end

    if v < a then
        return a
    end

    if v > b then
        return b
    end

    return v
end


-- ============================================================================
-- Money
-- ============================================================================

--- 1234567 -> "1,234,567"
function Utils.formatMoney(n)

    n = tonumber(n) or 0

    local negative = n < 0

    n = math.floor(math.abs(n))

    local s = tostring(n)

    local out = {}

    while #s > 3 do

        table.insert(
            out,
            1,
            s:sub(-3)
        )

        s = s:sub(1, -4)
    end

    table.insert(out, 1, s)

    local result = table.concat(out, ",")

    if negative then
        result = "-" .. result
    end

    return result
end


-- ============================================================================
-- Duration
-- ============================================================================

--- seconds -> "mm:ss" or "h:mm:ss"
function Utils.formatDuration(sec)

    sec = math.max(
        0,
        math.floor(tonumber(sec) or 0)
    )

    local h = math.floor(sec / 3600)

    local m = math.floor(
        (sec % 3600) / 60
    )

    local s = sec % 60

    if h > 0 then

        return string.format(
            "%d:%02d:%02d",
            h,
            m,
            s
        )
    end

    return string.format(
        "%02d:%02d",
        m,
        s
    )
end


-- ============================================================================
-- Real Time Helper
-- ============================================================================

function Utils.getRealTime()

    if type(getRealTime) == "function" then

        local ok, result = pcall(getRealTime)

        if ok and type(result) == "table" then
            return result
        end
    end

    -- Fallback
    return {
        hour = 12,
        min = 0,
        sec = 0,

        wday = 1,
        day = 1,
        month = 1,
        year = 2026
    }
end


-- ============================================================================
-- Clock
-- ============================================================================

--- real-time table -> "9:41"
function Utils.formatClock(dt)

    if type(dt) ~= "table" then
        dt = Utils.getRealTime()
    end

    local hour = tonumber(dt.hour) or 0
    local minute = tonumber(dt.min) or 0

    hour = hour % 12

    if hour == 0 then
        hour = 12
    end

    return string.format(
        "%d:%02d",
        hour,
        minute
    )
end


-- ============================================================================
-- Date
-- ============================================================================

local WEEKDAYS = {
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
}

local MONTHS = {
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
}


--- real-time table -> "Tue, 31 Aug"
function Utils.formatDate(dt)

    if type(dt) ~= "table" then
        dt = Utils.getRealTime()
    end

    local weekday =
        WEEKDAYS[tonumber(dt.wday) or 1]
        or "Day"

    local month =
        MONTHS[tonumber(dt.month) or 1]
        or ""

    local day =
        tonumber(dt.day) or 1

    return string.format(
        "%s, %d %s",
        weekday:sub(1, 3),
        day,
        month
    )
end


-- ============================================================================
-- Long Date
-- ============================================================================

local FULL_MONTHS = {
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
}


--- real-time table -> "Tuesday, August 31"
function Utils.formatDateLong(dt)

    if type(dt) ~= "table" then
        dt = Utils.getRealTime()
    end

    local weekday =
        WEEKDAYS[tonumber(dt.wday) or 1]
        or ""

    local month =
        FULL_MONTHS[tonumber(dt.month) or 1]
        or ""

    local day =
        tonumber(dt.day) or 1

    return string.format(
        "%s, %s %d",
        weekday,
        month,
        day
    )
end


-- ============================================================================
-- Time Ago
-- ============================================================================

--- timestamp -> "Now" / "4m" / "3h" / "5d"
function Utils.timeAgo(t)

    t = tonumber(t)

    if not t then
        return ""
    end

    local now = os.time()

    local diff = now - t

    -- حماية للوقت المستقبلي
    if diff < 0 then
        diff = 0
    end

    if diff < 45 then
        return "Now"
    end

    if diff < 3600 then

        return string.format(
            "%dm",
            math.max(
                1,
                math.floor(diff / 60)
            )
        )
    end

    if diff < 86400 then

        return string.format(
            "%dh",
            math.floor(diff / 3600)
        )
    end

    return string.format(
        "%dd",
        math.floor(diff / 86400)
    )
end


-- ============================================================================
-- Phone Number
-- ============================================================================

--- true when v is digits only and 8..12 chars
function Utils.isValidNumber(v)

    if v == nil then
        return false
    end

    v = tostring(v)

    return
        #v >= 8
        and #v <= 12
        and v:match("^%d+$") ~= nil
end


-- ============================================================================
-- Initials
-- ============================================================================

--- "Nadia Karim" -> "NK"
function Utils.initials(name)

    name = tostring(name or "")

    local result = {}

    for word in name:gmatch("%S+") do

        table.insert(
            result,
            word:sub(1, 1):upper()
        )

        -- لا نحتاج أكثر من حرفين
        if #result >= 2 then
            break
        end
    end

    local initials =
        table.concat(result)

    if #initials == 0 then
        return "?"
    end

    return initials
end


-- ============================================================================
-- Hash
-- ============================================================================

--- stable hash -> palette index 1..n
function Utils.hash(name, n)

    n = math.floor(tonumber(n) or 0)

    if n <= 0 then
        return 1
    end

    local hash = 0

    name = tostring(name or "?")

    for i = 1, #name do

        local byte =
            string.byte(name, i)

        hash =
            (hash * 31 + byte)
            % 1000003
    end

    return (hash % n) + 1
end